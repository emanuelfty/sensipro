# SensiPro — Android nativo (Kotlin + Jetpack Compose)

Base migrada desde `reference/index-mejorado-1.html` (copia intacta del original, sin modificar).

## Compilar
1. Android Studio (Koala o superior), JDK 17 → *Open* esta carpeta.
2. Sync Gradle (Android Studio genera `gradlew` y el wrapper jar si faltan) → Run.
3. Terminal: `./gradlew :app:assembleDebug`

## Mapa HTML → Kotlin
| Original (HTML/JS) | Kotlin |
|---|---|
| generateHash, getVal, statsFor, dpiFor, modelFlags, TIERS, buildConfig | data/SensiEngine.kt |
| I18N, X (política), T, TIPS, CHALL, OPT, FAQ, NAMES (solo es, extraídos del HTML) | data/EsData.kt (generado) |
| MODELS + EXTRA | data/Models.kt |
| BRANDS, WEAPONS, WCAT, WOFF, ICONS (SVG) | data/Catalog.kt, data/WeaponIcons.kt |
| store/localStorage (ff_recent, ff_favs, sp_cal, sp_opt, sp_ch) | data/Store.kt |
| Variables CSS :root / html.light | ui/Theme.kt |
| #viewHome, #viewGen, #viewCat, #viewMore, #viewInfo, #viewFeat | ui/Screens.kt |
| Modales (info, ajustes, soporte, nombres, favoritos, política) y navegación | ui/App.kt |
| saveGen (imagen), compartir, soporte, copiar | ui/Util.kt |
| HERO_IMGS (base64) | res/drawable-nodpi/hero_1.webp, hero_2.webp |

## Notas
- minSdk 29 (guardar imagen usa MediaStore sin permisos).
- Fuentes Orbitron/Poppins no incluidas aún (se usa la fuente del sistema).
- Mi dispositivo usa APIs reales de Android; los nombres de grupos/filas los puse yo (el original usa getDeviceInfo, líneas ~1357-1438).
- Idiomas: solo español portado; faltan en/pt/fr/de/it (están en I18N del HTML).
- Pendiente: paso de permisos tras la política, AdMob (IDs en líneas 1671-1673), animaciones/partículas, layout exacto de la imagen guardada (saveGen/saveCat, líneas 1168-1269), enlaces profundos ?m=&d= (handleDeepLink).

## Almacenamiento y acciones reales (ui/StorageManagement.kt)
- Consulta: StorageStatsManager (total/libre y tamaño propio, sin permisos) con StatFs de respaldo; imágenes propias vía MediaStore.
- Gestión: borrar caché propia, borrar imágenes guardadas por SensiPro, borrar datos guardados (con confirmación).
- Android no permite a una app liberar caché/archivos de otras apps ni cerrar apps: los botones de Optimizar abren el ajuste correspondiente del sistema.
- Sin permiso de archivos solo se ven/borran los archivos creados por esta instalación.

## Chat global (v1.2)
Pantalla `ui/ChatScreen.kt` + cliente `data/ChatRepository.kt`. Backend: **Firebase** (Authentication anónima + Cloud Firestore) por su API REST: sin plugin `google-services` ni dependencias nuevas.
- Los mensajes se guardan en Firestore (colección `chat_messages`); todos los usuarios leen la misma colección.
- Un mensaje solo se da por enviado cuando el servidor confirma la escritura (commit HTTP 200). No hay mensajes locales de relleno.
- Recepción: la pantalla consulta al servidor cada 3 s mientras está abierta y la app a la vista (no es push; con fallos espera más y reintenta).
- Estados: conectando / conectado / sin conexión / error (con el motivo) / no disponible (sin configurar).
- Límites: no vacío, máx. 300 caracteres (app y reglas), 1 mensaje cada 2 s por usuario (reglas), solo usuarios con sesión anónima, sin editar ni borrar mensajes.
- Permiso nuevo en el manifiesto: `INTERNET`.

### Configuración externa necesaria (una sola vez, se puede hacer desde el teléfono)
1. console.firebase.google.com → *Crear proyecto* (sin Analytics está bien).
2. *Build → Authentication → Comenzar → Método de acceso → Anónimo → Habilitar*.
3. *Build → Firestore Database → Crear base de datos* (modo producción, la región que prefieras).
4. En Firestore → pestaña *Reglas*: pega el contenido de `firestore.rules` → *Publicar*.
5. *Configuración del proyecto (engranaje) → General*: copia el **ID del proyecto** y la **Clave de API web** (si no aparece, añade una app web con el icono `</>`, o usa la "Browser key" de Google Cloud → APIs y servicios → Credenciales). No restrinjas esa clave a una app Android: las llamadas REST no envían el certificado.
6. En GitHub edita `app/src/main/res/values/chat_config.xml` y pon ambos valores entre las etiquetas `<string>`; commit y compila.
Mientras estén vacíos el chat muestra "no disponible" y no envía nada.
Coste/uso: cada usuario con el chat abierto hace ~20 consultas/min; el plan gratuito de Firestore (50 000 lecturas/día) alcanza para pocos usuarios activos. Si crece, hay que pasar a escucha en tiempo real o a otro plan.

## Comunidad (v1.6)
- Botón «Únete a la comunidad» en la pantalla principal: abre el enlace del canal en la app correspondiente o, si no está instalada, en el navegador.

## Anuncios AdMob (v1.7)
- IDs en `res/values/ads_config.xml` (bloques) y en el manifiesto (`APPLICATION_ID`). Banner inferior adaptable, intersticial cada 10 minutos con la app a la vista, y anuncio con recompensa: cada entrada a «Generar sensibilidad personalizada» gasta 1 uso; sin usos, un anuncio completo da 5 más (`Store.GEN_PER_AD`).
- Consentimiento con Google UMP (formulario donde sea obligatorio). Permiso nuevo: `com.google.android.gms.permission.AD_ID`.
- No hagas clic en tus propios anuncios (Google puede suspender la cuenta).
