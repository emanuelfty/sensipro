package com.jmz.sensipro.data

/** Datos de referencia copiados de BRANDS / WEAPONS / WCAT (es) / WOFF del HTML original. */
object Catalog {
    val BRANDS = listOf(
        "XIAOMI", "SAMSUNG", "HUAWEI", "MOTOROLA", "REALME", "INFINIX", "TECNO POP", "OPPO", "VIVO",
        "HONOR", "ONEPLUS", "LG", "ALCATEL", "ZTE", "BLU", "NOKIA", "TCL", "ASUS", "LENOVO", "APPLE", "SONY"
    )

    val WEAPON_CATEGORIES = linkedMapOf(
        "all" to "TODAS", "ar" to "FUSILES", "smg" to "SUBFUSILES", "sg" to "ESCOPETAS",
        "sn" to "FRANCOTIRADORES", "dmr" to "PRECISIÓN", "lmg" to "AMETRALLADORAS", "pis" to "PISTOLAS"
    )

    val WEAPON_OFFSET = mapOf("ar" to 0, "smg" to 5, "sg" to 10, "sn" to -10, "dmr" to -5, "lmg" to -8, "pis" to -5)

    /** (nombre, categoría, clave de icono) igual que WEAPONS del original. */
    val WEAPONS = listOf(
        Triple("AK", "ar", "ar"),
        Triple("M4A1", "ar", "ar"),
        Triple("SCAR", "ar", "ar"),
        Triple("GROZA", "ar", "ar2"),
        Triple("AN94", "ar", "ar2"),
        Triple("FAMAS", "ar", "ar2"),
        Triple("XM8", "ar", "ar2"),
        Triple("PARAFAL", "ar", "ar"),
        Triple("G36", "ar", "ar"),
        Triple("MP40", "smg", "smg"),
        Triple("UMP", "smg", "smg2"),
        Triple("THOMPSON", "smg", "smg"),
        Triple("MP5", "smg", "smg2"),
        Triple("P90", "smg", "smg2"),
        Triple("VECTOR", "smg", "smg2"),
        Triple("MAC-10", "smg", "smg2"),
        Triple("BIZON", "smg", "smg"),
        Triple("CG15", "smg", "smg"),
        Triple("UZI", "smg", "smg2"),
        Triple("M1887", "sg", "sg2"),
        Triple("M1014", "sg", "sg"),
        Triple("SPAS12", "sg", "sg"),
        Triple("MAG-7", "sg", "sg"),
        Triple("TROGON", "sg", "sg"),
        Triple("AWM", "sn", "sn"),
        Triple("KAR98K", "sn", "sn2"),
        Triple("M82B", "sn", "sn2"),
        Triple("AC80", "sn", "sn"),
        Triple("SKS", "dmr", "dmr"),
        Triple("WOODPECKER", "dmr", "dmr"),
        Triple("M14", "dmr", "dmr"),
        Triple("SVD", "dmr", "dmr"),
        Triple("VSS", "dmr", "dmr"),
        Triple("M60", "lmg", "lmg"),
        Triple("KORD", "lmg", "lmg"),
        Triple("DESERT EAGLE", "pis", "pistol"),
        Triple("M500", "pis", "revolver"),
        Triple("USP", "pis", "pistol"),
        Triple("G18", "pis", "pistol"),
        Triple("M1873", "pis", "revolver")
    )
}
