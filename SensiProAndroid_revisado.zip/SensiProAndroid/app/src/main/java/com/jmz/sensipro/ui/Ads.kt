package com.jmz.sensipro.ui

import android.app.Activity
import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.viewinterop.AndroidView
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.google.android.ump.ConsentInformation
import com.google.android.ump.ConsentRequestParameters
import com.google.android.ump.UserMessagingPlatform
import com.jmz.sensipro.R

/** Anuncios AdMob: banner inferior, intersticial cada 10 minutos y anuncio con recompensa opcional (Ajustes). */
object Ads {
    private const val INTERSTITIAL_EVERY_MS = 10 * 60 * 1000L

    /** Se vuelve true cuando se puede pedir anuncios (consentimiento resuelto y SDK iniciado). */
    var ready by mutableStateOf(false)
        private set
    /** Alto del banner cuando hay uno cargado (para no tapar contenido); false si falló la carga. */
    var bannerOk by mutableStateOf(true)

    private var started = false
    private var interstitial: InterstitialAd? = null
    private var rewarded: RewardedAd? = null
    private var interstitialLoading = false
    private var rewardedLoading = false
    private var resumed = false
    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            showInterstitial()
            handler.postDelayed(this, INTERSTITIAL_EVERY_MS)
        }
    }
    private var act: Activity? = null

    /** Consentimiento (UMP, requerido en el EEE/Reino Unido) y luego inicia el SDK. */
    fun start(a: Activity) {
        act = a
        if (started) return
        started = true
        val ci = UserMessagingPlatform.getConsentInformation(a)
        ci.requestConsentInfoUpdate(a, ConsentRequestParameters.Builder().build(), {
            UserMessagingPlatform.loadAndShowConsentFormIfRequired(a) { initIfAllowed(a, ci) }
        }, { initIfAllowed(a, ci) })
        initIfAllowed(a, ci)   // si ya hay consentimiento guardado de una sesión anterior
    }

    private var inited = false
    private fun initIfAllowed(a: Activity, ci: ConsentInformation) {
        if (inited || !ci.canRequestAds()) return
        inited = true
        MobileAds.initialize(a) {}
        ready = true
        loadInterstitial(a); loadRewarded(a)
        if (resumed) { handler.removeCallbacks(tick); handler.postDelayed(tick, INTERSTITIAL_EVERY_MS) }
    }

    fun onResume(a: Activity) {
        act = a; resumed = true
        if (inited) { handler.removeCallbacks(tick); handler.postDelayed(tick, INTERSTITIAL_EVERY_MS) }
    }

    fun onPause() { resumed = false; handler.removeCallbacks(tick) }

    private fun str(c: Context, id: Int) = c.getString(id).trim()

    private fun loadInterstitial(c: Context) {
        if (interstitial != null || interstitialLoading) return
        interstitialLoading = true
        InterstitialAd.load(c, str(c, R.string.admob_interstitial_id), AdRequest.Builder().build(), object : InterstitialAdLoadCallback() {
            override fun onAdLoaded(ad: InterstitialAd) { interstitial = ad; interstitialLoading = false }
            override fun onAdFailedToLoad(e: LoadAdError) { interstitial = null; interstitialLoading = false }
        })
    }

    private fun showInterstitial() {
        val a = act ?: return
        val ad = interstitial ?: run { loadInterstitial(a); return }
        if (!resumed || a.isFinishing) return
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() { interstitial = null; loadInterstitial(a) }
            override fun onAdFailedToShowFullScreenContent(e: AdError) { interstitial = null; loadInterstitial(a) }
        }
        ad.show(a)
    }

    private fun loadRewarded(c: Context) {
        if (rewarded != null || rewardedLoading) return
        rewardedLoading = true
        RewardedAd.load(c, str(c, R.string.admob_rewarded_id), AdRequest.Builder().build(), object : RewardedAdLoadCallback() {
            override fun onAdLoaded(ad: RewardedAd) { rewarded = ad; rewardedLoading = false }
            override fun onAdFailedToLoad(e: LoadAdError) { rewarded = null; rewardedLoading = false }
        })
    }

    /** Muestra el anuncio con recompensa; [onReward] solo se llama si el usuario lo ve completo. */
    fun showRewarded(a: Activity, onReward: () -> Unit, onUnavailable: () -> Unit) {
        val ad = rewarded
        if (ad == null) { loadRewarded(a); onUnavailable(); return }
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() { rewarded = null; loadRewarded(a) }
            override fun onAdFailedToShowFullScreenContent(e: AdError) { rewarded = null; loadRewarded(a) }
        }
        ad.show(a) { onReward() }
    }
}

/** Banner adaptable fijo en la parte inferior. No ocupa espacio si no se puede cargar. */
@Composable
fun BannerAd(modifier: Modifier = Modifier) {
    if (!Ads.ready || !Ads.bannerOk) return
    val width = LocalConfiguration.current.screenWidthDp
    AndroidView(modifier = modifier.fillMaxWidth(), factory = { c ->
        AdView(c).apply {
            setAdSize(AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(c, width))
            adUnitId = c.getString(R.string.admob_banner_id).trim()
            adListener = object : AdListener() {
                override fun onAdFailedToLoad(e: LoadAdError) { Ads.bannerOk = false }
            }
            loadAd(AdRequest.Builder().build())
        }
    })
}
