package com.jmz.sensipro

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.jmz.sensipro.data.Store
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.ui.Modifier
import com.jmz.sensipro.ui.Ads
import com.jmz.sensipro.ui.App
import com.jmz.sensipro.ui.BannerAd
import com.jmz.sensipro.ui.SensiTheme

class MainActivity : ComponentActivity() {
    private var fs = false
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            var dark by androidx.compose.runtime.remember { mutableStateOf(Store.get(this, "sp_theme") != "light") }
            SensiTheme(dark) {
                val showBanner = Ads.ready && Ads.bannerOk
                Column(Modifier.fillMaxSize()) {
                    androidx.compose.foundation.layout.Box(
                        Modifier.weight(1f).then(if (showBanner) Modifier.consumeWindowInsets(WindowInsets.navigationBars) else Modifier)
                    ) {
                        App(
                            dark = dark,
                            onToggleTheme = { dark = !dark; Store.set(this@MainActivity, "sp_theme", if (dark) "dark" else "light") },
                            onToggleFs = { toggleFs() },
                            onExit = { finish() }
                        )
                    }
                    BannerAd(Modifier.navigationBarsPadding())
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        Ads.start(this)
    }

    override fun onResume() { super.onResume(); Ads.onResume(this) }
    override fun onPause() { Ads.onPause(); super.onPause() }

    private fun toggleFs() {
        fs = !fs
        val c = WindowInsetsControllerCompat(window, window.decorView)
        if (fs) { c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE; c.hide(WindowInsetsCompat.Type.systemBars()) }
        else c.show(WindowInsetsCompat.Type.systemBars())
    }
}
