package com.jmz.sensipro.data

import android.content.Context
import com.jmz.sensipro.R
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.UUID

data class ChatMsg(val id: String, val uid: String, val text: String, val createdAt: String)

class ChatException(message: String, val kind: Kind) : Exception(message) {
    enum class Kind { CONFIG, NETWORK, AUTH, DENIED, RATE, SERVER }
}

/**
 * Cliente del chat global sobre Firebase (Authentication anónima + Cloud Firestore) usando solo su API REST.
 * Sin dependencias nuevas ni plugin google-services. Los mensajes viven en Firestore (remoto);
 * la app los recibe consultando al servidor cada pocos segundos mientras la pantalla está abierta.
 */
class ChatRepository(context: Context) {
    private val app = context.applicationContext
    private val projectId = app.getString(R.string.chat_firebase_project_id).trim()
    private val apiKey = app.getString(R.string.chat_firebase_api_key).trim()
    val configured: Boolean get() = projectId.isNotEmpty() && apiKey.isNotEmpty()

    @Volatile private var idToken: String? = null
    @Volatile private var tokenExpiry = 0L
    @Volatile var uid: String? = Store.get(app, "chat_uid")
        private set

    private val root get() = "projects/$projectId/databases/(default)/documents"
    private val fsBase get() = "https://firestore.googleapis.com/v1/$root"

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    // ------------------------------------------------------------------ HTTP
    private fun call(method: String, url: String, body: String?, contentType: String, bearer: String?): Pair<Int, String> {
        var c: HttpURLConnection? = null
        try {
            c = URL(url).openConnection() as HttpURLConnection
            c.requestMethod = method
            c.connectTimeout = 10_000
            c.readTimeout = 15_000
            c.setRequestProperty("Content-Type", contentType)
            c.setRequestProperty("Accept", "application/json")
            if (bearer != null) c.setRequestProperty("Authorization", "Bearer $bearer")
            if (body != null) {
                c.doOutput = true
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            return code to text
        } catch (e: IOException) {
            throw ChatException("Sin conexión con el servidor", ChatException.Kind.NETWORK)
        } finally {
            c?.disconnect()
        }
    }

    private fun errMsg(text: String): String = try {
        val t = text.trim()
        val o = if (t.startsWith("[")) JSONArray(t).getJSONObject(0) else JSONObject(t)
        o.getJSONObject("error").optString("message")
    } catch (e: Exception) { "" }

    private inline fun <T> guard(block: () -> T): T = try { block() } catch (e: JSONException) {
        throw ChatException("Respuesta inesperada del servidor", ChatException.Kind.SERVER)
    }

    // ------------------------------------------------------------------ Autenticación anónima
    private fun saveSession(id: String, refresh: String, expiresInSec: Long, userId: String) {
        idToken = id
        tokenExpiry = System.currentTimeMillis() + expiresInSec * 1000
        uid = userId
        Store.set(app, "chat_refresh", refresh)
        Store.set(app, "chat_uid", userId)
    }

    private fun authError(code: Int, text: String): ChatException {
        val m = errMsg(text)
        val msg = when {
            m.contains("OPERATION_NOT_ALLOWED") -> "Falta activar el acceso anónimo en Firebase Authentication"
            m.contains("API key") || m.contains("API_KEY") || m.contains("CONFIGURATION_NOT_FOUND") ->
                "Configuración de Firebase inválida (clave o proyecto): " + m.take(120)
            code in 500..599 -> "El servidor de autenticación no responde ($code)"
            else -> "Error de autenticación ($code) " + m.take(120)
        }
        val kind = if (code in 500..599) ChatException.Kind.SERVER else ChatException.Kind.AUTH
        return ChatException(msg.trim(), kind)
    }

    private fun signUp(): String {
        val (code, text) = call(
            "POST", "https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=" + enc(apiKey),
            JSONObject().put("returnSecureToken", true).toString(), "application/json", null
        )
        if (code !in 200..299) throw authError(code, text)
        val o = JSONObject(text)
        saveSession(o.getString("idToken"), o.getString("refreshToken"), o.getString("expiresIn").toLong(), o.getString("localId"))
        return o.getString("idToken")
    }

    private fun refreshSession(refresh: String): String {
        val (code, text) = call(
            "POST", "https://securetoken.googleapis.com/v1/token?key=" + enc(apiKey),
            "grant_type=refresh_token&refresh_token=" + enc(refresh), "application/x-www-form-urlencoded", null
        )
        if (code !in 200..299) throw authError(code, text)
        val o = JSONObject(text)
        saveSession(o.getString("id_token"), o.getString("refresh_token"), o.getString("expires_in").toLong(), o.getString("user_id"))
        return o.getString("id_token")
    }

    @Synchronized
    private fun token(force: Boolean = false): String {
        val t = idToken
        if (!force && t != null && System.currentTimeMillis() < tokenExpiry - 60_000) return t
        val refresh = Store.get(app, "chat_refresh")
        if (refresh != null) {
            try { return refreshSession(refresh) } catch (e: ChatException) {
                if (e.kind != ChatException.Kind.AUTH) throw e   // red/servidor: no crear otra identidad
            }
        }
        return signUp()
    }

    // ------------------------------------------------------------------ Firestore
    private fun fsError(code: Int, text: String): ChatException {
        val m = errMsg(text)
        return when {
            code == 429 -> ChatException("Demasiadas solicitudes; espera un momento", ChatException.Kind.RATE)
            code == 403 && (m.contains("has not been used") || m.contains("disabled")) ->
                ChatException("Cloud Firestore no está habilitado en el proyecto de Firebase", ChatException.Kind.CONFIG)
            code == 403 || code == 401 ->
                ChatException("El servidor denegó la operación (reglas de seguridad o límite de envío)", ChatException.Kind.DENIED)
            code == 404 -> ChatException("No existe la base de datos de Firestore en el proyecto", ChatException.Kind.CONFIG)
            else -> ChatException("Error del servidor ($code) " + m.take(120), ChatException.Kind.SERVER)
        }
    }

    private fun fs(path: String, body: String): String {
        var r = call("POST", fsBase + path, body, "application/json", token())
        if (r.first == 401) r = call("POST", fsBase + path, body, "application/json", token(force = true))
        if (r.first !in 200..299) throw fsError(r.first, r.second)
        return r.second
    }

    private fun parse(text: String): List<ChatMsg> {
        val arr = JSONArray(text)
        val out = ArrayList<ChatMsg>()
        for (i in 0 until arr.length()) {
            val d = arr.optJSONObject(i)?.optJSONObject("document") ?: continue
            val f = d.optJSONObject("fields") ?: continue
            val txt = f.optJSONObject("text")?.optString("stringValue") ?: continue
            val ts = f.optJSONObject("createdAt")?.optString("timestampValue") ?: continue
            val u = f.optJSONObject("uid")?.optString("stringValue") ?: ""
            out.add(ChatMsg(d.getString("name").substringAfterLast('/'), u, txt, ts))
        }
        return out
    }

    private fun query(since: String?): String {
        val sq = JSONObject()
            .put("from", JSONArray().put(JSONObject().put("collectionId", COLLECTION)))
            .put("orderBy", JSONArray().put(JSONObject()
                .put("field", JSONObject().put("fieldPath", "createdAt"))
                .put("direction", if (since == null) "DESCENDING" else "ASCENDING")))
            .put("limit", 100)
        if (since != null) sq.put("where", JSONObject().put("fieldFilter", JSONObject()
            .put("field", JSONObject().put("fieldPath", "createdAt"))
            .put("op", "GREATER_THAN_OR_EQUAL")
            .put("value", JSONObject().put("timestampValue", since))))
        return JSONObject().put("structuredQuery", sq).toString()
    }

    /** Últimos 100 mensajes guardados en el servidor, del más antiguo al más nuevo. */
    suspend fun loadRecent(): List<ChatMsg> = withContext(Dispatchers.IO) {
        guard { parse(fs(":runQuery", query(null))).reversed() }
    }

    /** Mensajes con fecha igual o posterior a [since] (el llamador descarta los ya conocidos por id). */
    suspend fun loadSince(since: String): List<ChatMsg> = withContext(Dispatchers.IO) {
        guard { parse(fs(":runQuery", query(since))) }
    }

    /**
     * Envía un mensaje. Solo retorna sin error cuando Firestore confirmó la escritura (HTTP 200 del commit).
     * Escribe de forma atómica el mensaje y la marca de último envío del usuario (las reglas la usan como límite de velocidad).
     */
    suspend fun send(text: String) = withContext(Dispatchers.IO) {
        guard {
            val clean = text.trim()
            if (clean.isEmpty() || clean.length > MAX_LEN) throw ChatException("Mensaje vacío o demasiado largo", ChatException.Kind.DENIED)
            token()
            val me = uid ?: throw ChatException("Sin identidad de usuario", ChatException.Kind.AUTH)
            val id = UUID.randomUUID().toString().replace("-", "")
            val serverTime = { field: String ->
                JSONArray().put(JSONObject().put("fieldPath", field).put("setToServerValue", "REQUEST_TIME"))
            }
            val msgWrite = JSONObject()
                .put("update", JSONObject()
                    .put("name", "$root/$COLLECTION/$id")
                    .put("fields", JSONObject()
                        .put("text", JSONObject().put("stringValue", clean))
                        .put("uid", JSONObject().put("stringValue", me))))
                .put("updateTransforms", serverTime("createdAt"))
                .put("currentDocument", JSONObject().put("exists", false))
            val userWrite = JSONObject()
                .put("update", JSONObject().put("name", "$root/$USERS/$me").put("fields", JSONObject()))
                .put("updateTransforms", serverTime("lastSent"))
            fs(":commit", JSONObject().put("writes", JSONArray().put(msgWrite).put(userWrite)).toString())
            Unit
        }
    }

    companion object {
        const val MAX_LEN = 300
        const val COLLECTION = "chat_messages"
        const val USERS = "chat_users"
    }
}
