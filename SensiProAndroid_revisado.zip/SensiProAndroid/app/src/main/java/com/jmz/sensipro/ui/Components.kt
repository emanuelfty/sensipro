package com.jmz.sensipro.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jmz.sensipro.data.SensiEngine
import com.jmz.sensipro.data.WeaponIcons

@Composable
fun PrimaryButton(text: String, modifier: Modifier = Modifier.fillMaxWidth(), enabled: Boolean = true, onClick: () -> Unit) {
    Box(
        modifier.clip(RoundedCornerShape(14.dp))
            .background(Brush.horizontalGradient(listOf(SensiColors.Primary, SensiColors.Accent)))
            .clickable(enabled = enabled, onClick = onClick).padding(vertical = 14.dp, horizontal = 16.dp),
        contentAlignment = Alignment.Center
    ) { Text(text, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp, textAlign = TextAlign.Center) }
}

@Composable
fun SheetButton(text: String, modifier: Modifier = Modifier.fillMaxWidth(), onClick: () -> Unit) {
    Box(
        modifier.clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.surface)
            .border(BorderStroke(1.dp, SensiColors.GlassBorder), RoundedCornerShape(14.dp))
            .clickable(onClick = onClick).padding(vertical = 13.dp, horizontal = 14.dp),
        contentAlignment = Alignment.Center
    ) { Text(text, color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, textAlign = TextAlign.Center) }
}

@Composable
fun Chip(text: String, selected: Boolean = false, onClick: () -> Unit) {
    Box(
        Modifier.clip(RoundedCornerShape(20.dp))
            .background(if (selected) SensiColors.Primary.copy(alpha = .25f) else MaterialTheme.colorScheme.surface)
            .border(BorderStroke(1.dp, if (selected) SensiColors.Primary else SensiColors.GlassBorder), RoundedCornerShape(20.dp))
            .clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 8.dp)
    ) { Text(text, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.SemiBold) }
}

@Composable
fun CardBox(modifier: Modifier = Modifier, border: Color = SensiColors.GlassBorder, content: @Composable () -> Unit) {
    Column(
        modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.surface)
            .border(BorderStroke(1.dp, border), RoundedCornerShape(16.dp)).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) { content() }
}

@Composable
fun StatRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .75f))
        Text(value, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
    }
}

@Composable
fun SectionHeader(text: String) {
    Text(text, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground.copy(alpha = .65f),
        modifier = Modifier.padding(top = 6.dp))
}

fun tierColor(id: String) = when (id) { "alta" -> SensiColors.TierAlta; "media" -> SensiColors.TierMedia; else -> SensiColors.TierBaja }

fun tierTitle(id: String) = when (id) { "alta" -> tr("high"); "media" -> tr("mid"); else -> tr("low") }

@Composable
fun TierCard(tid: String, dpiText: String?, stats: List<Pair<String, Int>>) {
    CardBox(border = tierColor(tid).copy(alpha = .5f)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(tierTitle(tid), color = tierColor(tid), fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            if (dpiText != null) Text(dpiText, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
        }
        stats.forEach { (k, v) -> StatRow(k, v.toString()) }
    }
}

val STAT_KEYS = listOf("g", "r", "m2", "m4", "awm", "lib")

fun weaponColor(cat: String) = when (cat) {
    "ar" -> Color(0xFFFF0055); "smg" -> Color(0xFFFF2D3D); "sg" -> Color(0xFFFFB300)
    "sn", "dmr" -> Color(0xFFFF6680); else -> Color(0xFF3DDC84)
}

@Composable
fun WeaponIcon(key: String, color: Color, modifier: Modifier) {
    val path = remember(key) { PathParser().parsePathString(WeaponIcons.MAP[key] ?: "M0 0").toPath() }
    Canvas(modifier) {
        val s = size.width / 64f
        withTransform({ scale(s, s, pivot = Offset.Zero) }) { drawPath(path, color) }
    }
}

fun statsPairs(s: com.jmz.sensipro.data.Stats): List<Pair<String, Int>> =
    listOf(tr("g") to s.g, tr("r") to s.r, tr("m2") to s.m2, tr("m4") to s.m4, tr("awm") to s.awm, tr("lib") to s.lib)

fun tiersOf(model: String, dpi: Boolean, offset: Int = 0): List<Triple<String, String?, List<Pair<String, Int>>>> {
    val seed = SensiEngine.seedFor(model); val f = SensiEngine.modelFlags(model)
    return SensiEngine.TIERS.map { t ->
        var s = SensiEngine.statsFor(seed, t, dpi, f)
        if (offset != 0) s = s.copy(
            g = (s.g + offset).coerceIn(0, 200), r = (s.r + offset).coerceIn(0, 200), m2 = (s.m2 + offset).coerceIn(0, 200),
            m4 = (s.m4 + offset).coerceIn(0, 200), lib = (s.lib + offset).coerceIn(0, 200)
        )
        Triple(t.id, if (dpi && seed != 0L) "DPI: ${SensiEngine.dpiFor(seed, t, f)}" else null, statsPairs(s))
    }
}
