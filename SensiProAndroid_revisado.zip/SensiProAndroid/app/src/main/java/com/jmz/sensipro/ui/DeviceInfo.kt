package com.jmz.sensipro.ui

import android.app.ActivityManager
import android.content.Context
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.hardware.Sensor
import android.hardware.SensorManager
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.GLES20
import android.os.BatteryManager
import android.os.Build
import android.os.Debug
import android.os.Environment
import android.os.Process
import android.os.StatFs
import android.util.DisplayMetrics
import android.view.WindowManager
import android.webkit.WebView
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale
import java.util.TimeZone

typealias DevGroup = Pair<String, List<Pair<String, String>>>

const val NA = "No disponible"
private const val YES = "Sí"
private const val NO = "No"

fun fmtB(b: Long): String =
    if (b >= 1_000_000_000L) String.format(Locale.US, "%.1f GB", b / 1e9) else "${Math.round(b / 1e6)} MB"

private fun yn(v: Boolean?) = when (v) { true -> YES; false -> NO; null -> NA }

fun dirSize(f: File): Long = try {
    if (f.isFile) f.length() else (f.listFiles() ?: emptyArray()).sumOf { dirSize(it) }
} catch (e: Exception) { 0L }

/** Procesador: SoC (API 31+) → /proc/cpuinfo "Hardware" → Build.HARDWARE. */
private fun cpuName(): String {
    if (Build.VERSION.SDK_INT >= 31) {
        val m = Build.SOC_MANUFACTURER; val n = Build.SOC_MODEL
        if (n.isNotBlank() && n != Build.UNKNOWN) return (if (m.isNotBlank() && m != Build.UNKNOWN) "$m " else "") + n
    }
    val hw = try {
        File("/proc/cpuinfo").readLines().firstOrNull { it.startsWith("Hardware") }?.substringAfter(":")?.trim()
    } catch (e: Exception) { null }
    return if (!hw.isNullOrEmpty()) hw else Build.HARDWARE
}

/** Frecuencia máxima de CPU; el sistema puede denegar la lectura (SELinux) → null. */
private fun maxCpuMhz(cores: Int): Int? = try {
    (0 until cores).mapNotNull {
        File("/sys/devices/system/cpu/cpu$it/cpufreq/cpuinfo_max_freq").readText().trim().toLongOrNull()
    }.maxOrNull()?.let { (it / 1000).toInt() }
} catch (e: Exception) { null }

/** GPU real vía contexto EGL/GLES2 mínimo (sin permisos). No se llama a eglTerminate para no afectar al render de la app. */
private fun glInfo(): Triple<String, String, String>? = try {
    val d = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
    val v = IntArray(2); EGL14.eglInitialize(d, v, 0, v, 1)
    val attr = intArrayOf(EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT, EGL14.EGL_SURFACE_TYPE, EGL14.EGL_PBUFFER_BIT, EGL14.EGL_NONE)
    val cfgs = arrayOfNulls<EGLConfig>(1); val n = IntArray(1)
    EGL14.eglChooseConfig(d, attr, 0, cfgs, 0, 1, n, 0)
    val c = EGL14.eglCreateContext(d, cfgs[0], EGL14.EGL_NO_CONTEXT, intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE), 0)
    val s = EGL14.eglCreatePbufferSurface(d, cfgs[0], intArrayOf(EGL14.EGL_WIDTH, 1, EGL14.EGL_HEIGHT, 1, EGL14.EGL_NONE), 0)
    EGL14.eglMakeCurrent(d, s, s, c)
    val r = GLES20.glGetString(GLES20.GL_RENDERER); val vd = GLES20.glGetString(GLES20.GL_VENDOR); val ver = GLES20.glGetString(GLES20.GL_VERSION)
    EGL14.eglMakeCurrent(d, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
    EGL14.eglDestroySurface(d, s); EGL14.eglDestroyContext(d, c)
    if (r == null) null else Triple(r, vd ?: NA, ver ?: NA)
} catch (e: Throwable) { null }

@Suppress("DEPRECATION")
fun readDeviceInfo(ctx: Context): List<DevGroup> {
    val pm = ctx.packageManager
    val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    val real = DisplayMetrics().also { wm.defaultDisplay.getRealMetrics(it) }
    val dm = ctx.resources.displayMetrics
    val cfg = ctx.resources.configuration
    val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
    val cores = Runtime.getRuntime().availableProcessors()
    val gl = glInfo()
    val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager

    // Dispositivo
    val brand = Build.MANUFACTURER.replaceFirstChar { it.uppercase() }
    val abi = Build.SUPPORTED_ABIS.firstOrNull() ?: NA
    val g1 = listOf(
        "Modelo" to Build.MODEL, "Fabricante" to brand, "Sistema" to "Android", "Versión" to Build.VERSION.RELEASE,
        "Arquitectura" to "$abi · ${if (Process.is64Bit()) 64 else 32} bits", "Nivel de API" to "API ${Build.VERSION.SDK_INT}"
    )
    // Pantalla
    val hz = wm.defaultDisplay.refreshRate
    val g2 = listOf(
        "Resolución real" to "${real.widthPixels} × ${real.heightPixels} px",
        "Tamaño lógico" to "${(dm.widthPixels / dm.density).toInt()} × ${(dm.heightPixels / dm.density).toInt()}",
        "Densidad" to String.format(Locale.US, "%.2fx", dm.density), "DPI" to "${dm.densityDpi} dpi",
        "Frecuencia" to Math.round(hz).toString() + " Hz",
        "Orientación" to if (cfg.orientation == Configuration.ORIENTATION_LANDSCAPE) "Horizontal" else "Vertical"
    )
    // Procesador y GPU
    val mhz = maxCpuMhz(cores)
    val g3 = listOf(
        "Procesador" to cpuName(), "Núcleos" to cores.toString(), "Frecuencia máx." to (mhz?.let { "$it MHz" } ?: NA),
        "GPU" to (gl?.first ?: NA), "Fabricante GPU" to (gl?.second ?: NA)
    )
    // Memoria y almacenamiento
    val st = try { StatFs(Environment.getDataDirectory().path).let { it.totalBytes to it.availableBytes } } catch (e: Exception) { null }
    val appBytes = dirSize(ctx.dataDir)
    val pss = try { Debug.MemoryInfo().also { Debug.getMemoryInfo(it) }.totalPss.toLong() * 1024 } catch (e: Exception) { 0L }
    val g4 = listOf(
        "RAM" to fmtB(mi.totalMem), "RAM disponible" to fmtB(mi.availMem),
        "Almacenamiento (libre / total)" to (st?.let { fmtB(it.second) + " / " + fmtB(it.first) } ?: NA),
        "Usado por la app" to fmtB(appBytes), "Memoria usada por la app" to (if (pss > 0) fmtB(pss) else NA)
    )
    // Batería y red
    val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
    val bat = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
    val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    val caps = try { cm.getNetworkCapabilities(cm.activeNetwork) } catch (e: Exception) { null }
    val net = when {
        caps == null -> NA
        caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "WIFI"
        caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "MÓVIL"
        caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "ETHERNET"
        else -> "OTRA"
    }
    val g5 = listOf(
        "Batería" to (if (bat in 0..100) "$bat %" else NA), "Cargando" to yn(bm.isCharging), "Conexión" to net,
        "Velocidad" to (caps?.let { "${it.linkDownstreamBandwidthKbps / 1000} Mbps (estimada por el sistema)" } ?: NA),
        "En línea" to yn(caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET))
    )
    // Sistema
    val touch = when {
        pm.hasSystemFeature(PackageManager.FEATURE_TOUCHSCREEN_MULTITOUCH_JAZZHAND) -> "5 o más"
        pm.hasSystemFeature(PackageManager.FEATURE_TOUCHSCREEN_MULTITOUCH_DISTINCT) -> "2 o más"
        pm.hasSystemFeature(PackageManager.FEATURE_TOUCHSCREEN) -> "1"
        else -> NA
    }
    val g6 = listOf("Idioma" to Locale.getDefault().toLanguageTag(), "Zona horaria" to TimeZone.getDefault().id, "Puntos táctiles" to touch)
    // Hardware
    val cams = try { (ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager).cameraIdList.size.toString() } catch (e: Exception) { NA }
    val mics = try { (ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager).microphones.size.toString() }
        catch (e: Exception) { yn(pm.hasSystemFeature(PackageManager.FEATURE_MICROPHONE)) }
    val ci = am.deviceConfigurationInfo
    val gles = "${ci.reqGlEsVersion shr 16}.${ci.reqGlEsVersion and 0xFFFF}"
    val g7 = listOf(
        "Cámaras" to cams, "Micrófonos" to mics,
        "Acelerómetro" to yn(sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) != null),
        "Giroscopio" to yn(sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE) != null),
        "Magnetómetro" to yn(sm.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD) != null),
        "Bluetooth" to yn(pm.hasSystemFeature(PackageManager.FEATURE_BLUETOOTH)),
        "Pantalla HDR" to yn(cfg.isScreenHdr), "Gama amplia (P3)" to yn(cfg.isScreenWideColorGamut),
        "OpenGL ES" to (gl?.third ?: gles)
    )
    // Avanzado
    val wv = try { WebView.getCurrentWebViewPackage()?.let { it.packageName + " " + it.versionName } ?: NA } catch (e: Throwable) { NA }
    val emu = Build.FINGERPRINT.startsWith("generic") || Build.FINGERPRINT.contains("emulator") ||
        Build.HARDWARE.contains("goldfish") || Build.HARDWARE.contains("ranchu") || Build.PRODUCT.contains("sdk")
    val saver = try {
        when (cm.restrictBackgroundStatus) { ConnectivityManager.RESTRICT_BACKGROUND_STATUS_DISABLED -> NO; else -> YES }
    } catch (e: Exception) { NA }
    val g8 = listOf(
        "WebView / Chromium" to wv, "Emulador" to yn(emu),
        "Heap de la app (límite)" to "${am.memoryClass} MB", "Ahorro de datos" to saver
    )
    return listOf(
        "📱 DISPOSITIVO" to g1, "🖥️ PANTALLA" to g2, "⚙️ PROCESADOR Y GPU" to g3, "🧠 MEMORIA" to g4,
        "🔋 BATERÍA Y RED" to g5, "🌐 SISTEMA" to g6, "🧩 HARDWARE" to g7, "🧪 AVANZADO" to g8
    )
}

@Composable
fun DevScreen(onBack: () -> Unit, onMine: (String) -> Unit) {
    val ctx = LocalContext.current
    var groups by remember { mutableStateOf<List<DevGroup>?>(null) }
    var key by remember { mutableStateOf(0) }
    LaunchedEffect(key) {
        groups = null
        groups = try { withContext(Dispatchers.IO) { readDeviceInfo(ctx) } } catch (e: Throwable) { emptyList() }
    }
    ScreenFrame("MI DISPOSITIVO", onBack) {
        Text(
            "Lecturas reales del sistema Android. Datos que Android no permite leer a una app normal " +
                "(número de serie, IMEI) no se muestran; si un dato no está disponible aparece como «$NA».",
            fontSize = 12.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = .65f)
        )
        val g = groups
        if (g == null) Text("Leyendo información...", color = MaterialTheme.colorScheme.onBackground)
        else g.forEach { (t, rows) ->
            CardBox { Text(t, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold, color = SensiColors.Primary); rows.forEach { StatRow(it.first, it.second) } }
        }
        PrimaryButton("🎯 VER SENSI DE MI DISPOSITIVO") {
            val b = Build.MANUFACTURER.replaceFirstChar { it.uppercase() }; val m = Build.MODEL
            val full = (if (!m.lowercase().startsWith(b.lowercase())) "$b " else "") + m
            onMine(full.uppercase())
        }
        SheetButton("🔄 ACTUALIZAR") { key++ }
        SheetButton("📋 COPIAR INFO") {
            val list = groups ?: return@SheetButton
            copyText(ctx, "📱 SensiPro\n\n" + list.joinToString("\n\n") { gr -> gr.first + "\n" + gr.second.joinToString("\n") { it.first + ": " + it.second } })
            toast(ctx, tr("copied"))
        }
    }
}
