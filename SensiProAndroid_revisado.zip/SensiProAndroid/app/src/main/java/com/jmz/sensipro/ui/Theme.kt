package com.jmz.sensipro.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Variables CSS del original (:root y html.light)
object SensiColors {
    val Primary = Color(0xFFFF2D3D)
    val Secondary = Color(0xFFC4001F)
    val Accent = Color(0xFFFF0055)
    val BgDark = Color(0xFF050508)
    val Surface = Color(0xFF12121C)
    val Surface2 = Color(0xFF181826)
    val GlassBorder = Color(0x1AFFFFFF)
    val TierAlta = Color(0xFFFF0055)
    val TierMedia = Color(0xFFFFCA28)
    val TierBaja = Color(0xFFFF2D3D)
    val BgLight = Color(0xFFEEF1F7)
    val PrimaryLight = Color(0xFFC81E28)
}

@Composable
fun SensiTheme(dark: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    val scheme = if (dark) darkColorScheme(
        primary = SensiColors.Primary, secondary = SensiColors.Secondary, tertiary = SensiColors.Accent,
        background = SensiColors.BgDark, surface = SensiColors.Surface, surfaceVariant = SensiColors.Surface2
    ) else lightColorScheme(
        primary = SensiColors.PrimaryLight, background = SensiColors.BgLight, surface = Color.White
    )
    MaterialTheme(colorScheme = scheme, content = content)
}
