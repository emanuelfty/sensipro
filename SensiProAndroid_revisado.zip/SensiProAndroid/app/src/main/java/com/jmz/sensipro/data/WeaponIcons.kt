package com.jmz.sensipro.data

/** Trazos SVG (viewBox 64x30) copiados de ICONS del original. */
object WeaponIcons {
    val MAP: Map<String, String> = mapOf(
        "pistol" to "M10 9h40v7H34l-3 11h-8l3-11H10z",
        "revolver" to "M6 9h36v6H30l-3 5h-6l2-5h-5l-4 11H8l5-11H6z",
        "smg" to "M6 9h38v8H30v10h-7V17H6zM44 10h14v5H44z",
        "smg2" to "M4 10h34l4 3h14v5H42l-3 3h-8v8h-6v-8H4zM12 18h8v10h-8z",
        "ar" to "M2 11h22V8h20l4 4h14v5H46l-4-2H31l-1 12h-7l1-12H24v-3H2z",
        "ar2" to "M3 12h18l2-3h22l5 3h11v6H48l-4 3H34l-1 9h-7l1-9H3z",
        "sg" to "M2 12h38v4H2zM16 16h14v4H16zM40 11h8l14 7v5l-6 1-7-5h-9z",
        "sg2" to "M2 10h40v3H2zM2 14h40v3H2zM42 10h8l12 8v5l-6 1-8-6h-6z",
        "dmr" to "M2 12h40l3-3h5v4h14v3H44l-5 4h-8l2-4H2zM18 5h16v4H18z",
        "sn" to "M1 13h62v3H46l-4 4h-7l2-4H1zM14 6h20v4H14zM44 16h14l4 8h-8z",
        "sn2" to "M1 14h44l4-3h6l2 3h6v4H55l-6 4H34l-3 6h-6l2-6H1zM12 6h22v4H12z",
        "lmg" to "M2 12h20V9h24l4 4h14v6H50l-5-2H36l-2 4h-3l-1 6h-7l1-6H2zM36 22h8v8h-8z")
}
