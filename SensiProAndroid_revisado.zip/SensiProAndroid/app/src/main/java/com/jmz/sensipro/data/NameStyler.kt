package com.jmz.sensipro.data

import java.text.Normalizer
import kotlin.random.Random

/**
 * Lógica de «Crear nombres insanos»: convierte un nombre a distintas fuentes Unicode
 * y lo combina con símbolos. No depende de Android: el chequeo de que el teléfono
 * pueda dibujar cada carácter se inyecta como [has].
 */
object NameStyler {

    class Font(val label: String, private val tr: (Char) -> String?) {
        fun apply(base: String): String {
            val sb = StringBuilder()
            stripAccents(base).forEach { c -> sb.append(tr(c) ?: c.toString()) }
            return sb.toString()
        }
    }

    class Deco(val pre: String, val post: String)

    class Result(val fontLabel: String, val text: String)

    const val DECO_RANDOM = -2
    const val DECO_NONE = -1

    fun stripAccents(s: String): String =
        Normalizer.normalize(s, Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "")

    private fun cp(code: Int) = String(Character.toChars(code))

    private fun math(
        label: String, upper: Int, lower: Int, digit: Int? = null, ex: Map<Char, Int> = emptyMap()
    ) = Font(label) { c ->
        val code: Int? = ex[c] ?: when (c) {
            in 'A'..'Z' -> upper + (c - 'A')
            in 'a'..'z' -> lower + (c - 'a')
            in '0'..'9' -> if (digit != null) digit + (c - '0') else null
            else -> null
        }
        code?.let { cp(it) }
    }

    private const val SMALL_CAPS = "ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘǫʀꜱᴛᴜᴠᴡxʏᴢ"

    private val circledDigits: Map<Char, Int> =
        ('1'..'9').associateWith { 0x2460 + (it - '1') } + mapOf('0' to 0x24EA)

    val FONTS: List<Font> = listOf(
        math("Negrita", 0x1D400, 0x1D41A, 0x1D7CE),
        math("Cursiva", 0x1D434, 0x1D44E, null, mapOf('h' to 0x210E)),
        math("Negrita cursiva", 0x1D468, 0x1D482),
        math(
            "Script", 0x1D49C, 0x1D4B6, null,
            mapOf(
                'B' to 0x212C, 'E' to 0x2130, 'F' to 0x2131, 'H' to 0x210B, 'I' to 0x2110,
                'L' to 0x2112, 'M' to 0x2133, 'R' to 0x211B, 'e' to 0x212F, 'g' to 0x210A, 'o' to 0x2134
            )
        ),
        math("Script negrita", 0x1D4D0, 0x1D4EA),
        math(
            "Gótica", 0x1D504, 0x1D51E, null,
            mapOf('C' to 0x212D, 'H' to 0x210C, 'I' to 0x2111, 'R' to 0x211C, 'Z' to 0x2128)
        ),
        math("Gótica negrita", 0x1D56C, 0x1D586),
        math(
            "Doble trazo", 0x1D538, 0x1D552, 0x1D7D8,
            mapOf('C' to 0x2102, 'H' to 0x210D, 'N' to 0x2115, 'P' to 0x2119, 'Q' to 0x211A, 'R' to 0x211D, 'Z' to 0x2124)
        ),
        math("Sans", 0x1D5A0, 0x1D5BA, 0x1D7E2),
        math("Sans negrita", 0x1D5D4, 0x1D5EE, 0x1D7EC),
        math("Sans cursiva", 0x1D608, 0x1D622),
        math("Sans negrita cursiva", 0x1D63C, 0x1D656),
        math("Monoespaciada", 0x1D670, 0x1D68A, 0x1D7F6),
        Font("Versalita") { c ->
            val l = c.lowercaseChar()
            if (l in 'a'..'z') SMALL_CAPS[l - 'a'].toString() else null
        },
        math("Circular", 0x24B6, 0x24D0, null, circledDigits),
        math("Ancho completo", 0xFF21, 0xFF41, 0xFF10)
    )

    val DECOS: List<Deco> = listOf(
        Deco("꧁༒", "༒꧂"), Deco("★彡", "彡★"), Deco("꧁☬", "☬꧂"), Deco("☠", "☠"),
        Deco("⚡", "⚡"), Deco("♛", "♛"), Deco("✦", "✦"), Deco("『", "』"),
        Deco("【", "】"), Deco("ミ★", "★ミ"), Deco("", "🔥"), Deco("ツ", ""),
        Deco("", "✿"), Deco("•", "•"), Deco("☬", ""), Deco("♨", "")
    )

    /** true si todos los caracteres (salvo ASCII y espacios) los puede dibujar el dispositivo. */
    fun supported(s: String, has: (Int) -> Boolean): Boolean {
        var i = 0
        while (i < s.length) {
            val c = s.codePointAt(i)
            if (c >= 128 && !Character.isWhitespace(c) && !has(c)) return false
            i += Character.charCount(c)
        }
        return true
    }

    fun availableFonts(base: String, has: (Int) -> Boolean): List<Font> =
        FONTS.filter { supported(it.apply(base), has) }

    fun availableDecos(has: (Int) -> Boolean): List<Deco> =
        DECOS.filter { supported(it.pre + it.post, has) }

    /**
     * Un resultado por fuente disponible. [fontLabel] == null → todas las fuentes.
     * [decoSel]: DECO_RANDOM (símbolo distinto al azar en cada resultado), DECO_NONE o índice en [decos].
     */
    fun build(
        base: String, fontLabel: String?, decoSel: Int, decos: List<Deco>, rnd: Random, has: (Int) -> Boolean
    ): List<Result> {
        val b = base.trim()
        if (b.isEmpty()) return emptyList()
        return availableFonts(b, has)
            .filter { fontLabel == null || it.label == fontLabel }
            .map { f ->
                val d: Deco? = when {
                    decoSel == DECO_NONE || decos.isEmpty() -> null
                    decoSel == DECO_RANDOM -> decos[rnd.nextInt(decos.size)]
                    else -> decos.getOrNull(decoSel)
                }
                Result(f.label, (d?.pre ?: "") + f.apply(b) + (d?.post ?: ""))
            }
    }
}
