package com.jmz.sensipro.ui

import android.app.usage.StorageStatsManager
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Process
import android.os.StatFs
import android.os.Environment
import android.os.storage.StorageManager
import android.provider.MediaStore
import android.provider.Settings
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Acciones reales de "Optimizar": abren la pantalla de ajustes de Android correspondiente (la app no puede cambiar esos ajustes por sí sola). */
val OPT_ACTIONS: Map<Int, Pair<String, List<String>>> = mapOf(
    0 to ("📲 ABRIR LISTA DE APPS (Android no permite que una app cierre otras)" to listOf(Settings.ACTION_APPLICATION_SETTINGS)),
    1 to ("🔕 ABRIR AJUSTES DE NO MOLESTAR" to listOf("android.settings.ZEN_MODE_PRIORITY_SETTINGS", Settings.ACTION_SOUND_SETTINGS)),
    2 to ("🔋 ABRIR AHORRO DE BATERÍA" to listOf(Settings.ACTION_BATTERY_SAVER_SETTINGS)),
    4 to ("🖥️ ABRIR AJUSTES DE PANTALLA" to listOf(Settings.ACTION_DISPLAY_SETTINGS)),
    5 to ("📶 ABRIR AJUSTES DE WI‑FI" to listOf(Settings.ACTION_WIFI_SETTINGS)),
    6 to ("⬆️ ABRIR INFORMACIÓN DEL SISTEMA" to listOf("android.settings.SYSTEM_UPDATE_SETTINGS", Settings.ACTION_DEVICE_INFO_SETTINGS))
)

fun openSettings(ctx: Context, actions: List<String>, forThisApp: Boolean = false): Boolean {
    for (a in actions) {
        try {
            val i = Intent(a)
            if (forThisApp) i.data = Uri.parse("package:" + ctx.packageName)
            ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return true
        } catch (e: Exception) { /* probar la siguiente */ }
    }
    return false
}

data class StorageReport(
    val total: Long?, val free: Long?, val appTotal: Long?, val appData: Long?, val appCache: Long?,
    val cacheOnDisk: Long, val imgCount: Int, val imgBytes: Long
)

private val IMG_URI: Uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI

/** Imágenes guardadas por SensiPro. Sin permiso de archivos, Android solo devuelve las creadas por esta instalación. */
fun savedImages(ctx: Context): List<Pair<Uri, Long>> {
    val out = mutableListOf<Pair<Uri, Long>>()
    try {
        ctx.contentResolver.query(
            IMG_URI, arrayOf(MediaStore.Images.Media._ID, MediaStore.Images.Media.SIZE),
            MediaStore.Images.Media.RELATIVE_PATH + " LIKE ?", arrayOf("Pictures/SensiPro%"), null
        )?.use { c -> while (c.moveToNext()) out.add(ContentUris.withAppendedId(IMG_URI, c.getLong(0)) to c.getLong(1)) }
    } catch (e: Exception) { /* sin acceso: lista vacía */ }
    return out
}

private fun cacheDirs(ctx: Context) = listOfNotNull(ctx.cacheDir, ctx.codeCacheDir, ctx.externalCacheDir)

fun readStorage(ctx: Context): StorageReport {
    var total: Long? = null; var free: Long? = null
    var appTotal: Long? = null; var appData: Long? = null; var appCache: Long? = null
    try {
        val ssm = ctx.getSystemService(Context.STORAGE_STATS_SERVICE) as StorageStatsManager
        try { total = ssm.getTotalBytes(StorageManager.UUID_DEFAULT); free = ssm.getFreeBytes(StorageManager.UUID_DEFAULT) } catch (e: Exception) {}
        try {
            val st = ssm.queryStatsForPackage(StorageManager.UUID_DEFAULT, ctx.packageName, Process.myUserHandle())
            appTotal = st.appBytes + st.dataBytes; appData = st.dataBytes; appCache = st.cacheBytes
        } catch (e: Exception) {}
    } catch (e: Exception) {}
    if (total == null || free == null) try {
        val s = StatFs(Environment.getDataDirectory().path); total = s.totalBytes; free = s.availableBytes
    } catch (e: Exception) {}
    val imgs = savedImages(ctx)
    return StorageReport(total, free, appTotal, appData, appCache, cacheDirs(ctx).sumOf { dirSize(it) }, imgs.size, imgs.sumOf { it.second })
}

@Composable
fun StorageCard() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var rep by remember { mutableStateOf<StorageReport?>(null) }
    var key by remember { mutableStateOf(0) }
    var confirm by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(key) { rep = withContext(Dispatchers.IO) { readStorage(ctx) } }
    val dim = MaterialTheme.colorScheme.onSurface.copy(alpha = .7f)

    CardBox {
        Text("💾 ALMACENAMIENTO", fontWeight = FontWeight.Bold, color = SensiColors.Primary)
        val r = rep
        if (r == null) Text("Leyendo información...", color = dim)
        else {
            StatRow("Total del dispositivo", r.total?.let { fmtB(it) } ?: NA)
            StatRow("Libre", r.free?.let { fmtB(it) } ?: NA)
            StatRow("Usado por SensiPro", r.appTotal?.let { fmtB(it) } ?: NA)
            StatRow("Datos de SensiPro", r.appData?.let { fmtB(it) } ?: NA)
            StatRow("Caché de SensiPro", fmtB(r.appCache ?: r.cacheOnDisk))
            StatRow("Imágenes guardadas por SensiPro", "${r.imgCount} · ${fmtB(r.imgBytes)}")
            Text(
                "Sin permisos especiales Android solo permite ver y borrar lo que SensiPro creó. " +
                    "No puede liberar la caché ni los archivos de otras apps: eso se hace desde los ajustes de Android.",
                fontSize = 12.sp, color = dim
            )
        }
        SheetButton("🧹 BORRAR CACHÉ DE SENSIPRO") {
            scope.launch {
                val (before, after) = withContext(Dispatchers.IO) {
                    val d = cacheDirs(ctx); val b = d.sumOf { dirSize(it) }
                    d.forEach { dir -> dir.listFiles()?.forEach { it.deleteRecursively() } }
                    b to d.sumOf { dirSize(it) }
                }
                toast(ctx, if (before == 0L) "No había caché que borrar." else if (after < before) "Caché borrada: ${fmtB(before - after)} liberados." else "Android no permitió borrar la caché.")
                key++
            }
        }
        SheetButton("🖼️ BORRAR IMÁGENES GUARDADAS POR SENSIPRO") { confirm = "img" }
        SheetButton("🗑️ BORRAR DATOS GUARDADOS (recientes, favoritos, calibración, retos)") { confirm = "data" }
        SheetButton("⚙️ ABRIR ALMACENAMIENTO DE ANDROID") {
            if (!openSettings(ctx, listOf(Settings.ACTION_INTERNAL_STORAGE_SETTINGS))) toast(ctx, "Este dispositivo no permite abrir los ajustes de almacenamiento.")
        }
        SheetButton("📂 AJUSTES DE SENSIPRO (permisos, borrar datos)") {
            if (!openSettings(ctx, listOf(Settings.ACTION_APPLICATION_DETAILS_SETTINGS), true)) toast(ctx, "Este dispositivo no permite abrir los ajustes de la app.")
        }
    }

    when (confirm) {
        "img" -> SheetDialog("¿Borrar imágenes guardadas?", { confirm = null }) {
            Text("Se borrarán de Imágenes/SensiPro las que creó esta app. No se puede deshacer.", color = MaterialTheme.colorScheme.onSurface)
            PrimaryButton("BORRAR") {
                confirm = null
                scope.launch {
                    val list = withContext(Dispatchers.IO) { savedImages(ctx) }
                    var ok = 0; var fail = 0
                    withContext(Dispatchers.IO) {
                        list.forEach { (u, _) -> try { if (ctx.contentResolver.delete(u, null, null) > 0) ok++ else fail++ } catch (e: SecurityException) { fail++ } }
                    }
                    toast(ctx, when {
                        list.isEmpty() -> "No hay imágenes guardadas por SensiPro."
                        fail == 0 -> "$ok imagen(es) borrada(s)."
                        else -> "$ok borrada(s). Android impidió borrar $fail (ya no pertenecen a esta instalación); bórralas desde la Galería."
                    })
                    key++
                }
            }
            SheetButton("CANCELAR") { confirm = null }
        }
        "data" -> SheetDialog("¿Borrar datos guardados?", { confirm = null }) {
            Text("Se borrarán recientes, favoritos, calibración, optimización y retos. Se conservan la política aceptada y el tema. No se puede deshacer.", color = MaterialTheme.colorScheme.onSurface)
            PrimaryButton("BORRAR") {
                confirm = null
                val sp = ctx.getSharedPreferences("sensipro", Context.MODE_PRIVATE)
                val keep = setOf("ff_policy", "sp_theme")
                val e = sp.edit(); sp.all.keys.filter { it !in keep }.forEach { e.remove(it) }
                toast(ctx, if (e.commit()) "Datos guardados borrados." else "Android no permitió borrar los datos.")
                key++
            }
            SheetButton("CANCELAR") { confirm = null }
        }
        else -> {}
    }
}
