package com.jmz.sensipro.ui

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.view.Display
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.layout.offset
import com.jmz.sensipro.R
import com.jmz.sensipro.data.Catalog
import com.jmz.sensipro.data.EsData
import com.jmz.sensipro.data.Models
import com.jmz.sensipro.data.SensiEngine
import com.jmz.sensipro.data.Store
import kotlinx.coroutines.delay
import kotlin.math.hypot
import kotlin.random.Random

@Composable
fun ScreenFrame(title: String, onBack: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(40.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surface).clickable(onClick = onBack),
                contentAlignment = Alignment.Center
            ) { Text("←", fontSize = 20.sp, color = MaterialTheme.colorScheme.onSurface) }
            Spacer(Modifier.width(12.dp))
            Text(title, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = SensiColors.Primary)
        }
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp), content = content
        )
        Spacer(Modifier.navigationBarsPadding())
    }
}

// ---------------------------------------------------------------- HOME
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun HomeScreen(
    dark: Boolean, onToggleTheme: () -> Unit, onToggleFs: () -> Unit,
    onGen: (String) -> Unit, onFeat: (String) -> Unit, onBrand: (String) -> Unit, onMore: () -> Unit,
    onCatalog: (String, List<String>, String, Int) -> Unit, onMenu: (String) -> Unit, recentsVersion: Int
) {
    val ctx = LocalContext.current
    var wCat by remember { mutableStateOf("all") }
    var menu by remember { mutableStateOf(false) }
    val hero = remember { listOf(R.drawable.hero_1, R.drawable.hero_2).random() }
    val recents = remember(recentsVersion) { Store.recents(ctx) }
    val tiles = listOf("dev" to "📱", "cal" to "🎯", "opt" to "⚡", "tip" to "💡", "ch" to "🏆", "help" to "❓")

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).verticalScroll(rememberScrollState())) {
        Box(Modifier.fillMaxWidth().height(260.dp)) {
            Image(painterResource(hero), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            Box(Modifier.fillMaxSize().background(Color(0x66050508)))
            Row(Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                HeroBtn("⛶") { onToggleFs() }
                HeroBtn(if (dark) "☀" else "🌙") { onToggleTheme() }
                HeroBtn("?") { onMenu("help") }
                Box {
                    HeroBtn("⋮") { menu = true }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        listOf(
                            "saved" to tr("menuSaved"), "names" to tr("namesBtn"), "chat" to CHAT_LABEL, "boost" to BOOST_LABEL, "dev" to tr("devBtn"), "req" to tr("menuReq"),
                            "apps" to tr("menuApps"), "share" to tr("menuShare"), "about" to tr("menuAbout"),
                            "priv" to tr("menuPriv"), "set" to tr("menuSet")
                        ).forEach { (k, label) -> DropdownMenuItem(text = { Text(label) }, onClick = { menu = false; onMenu(k) }) }
                    }
                }
            }
            Text("SENSIPRO", Modifier.align(Alignment.BottomStart).padding(16.dp), color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Black)
        }
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            PrimaryButton(tr("custom")) { onGen("") }
            tiles.chunked(2).forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    row.forEach { (k, ic) ->
                        Column(
                            Modifier.weight(1f).clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.surface)
                                .border(androidx.compose.foundation.BorderStroke(1.dp, SensiColors.GlassBorder), RoundedCornerShape(14.dp))
                                .clickable { onFeat(k) }.padding(14.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) { Text(ic, fontSize = 24.sp); Text(tt(k), fontSize = 12.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurface) }
                    }
                }
            }
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Catalog.WEAPON_CATEGORIES.forEach { (k, label) -> Chip(label, wCat == k) { wCat = k } }
            }
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Catalog.WEAPONS.filter { wCat == "all" || it.second == wCat }.forEach { (name, cat, icon) ->
                    val col = weaponColor(cat)
                    Row(
                        Modifier.clip(RoundedCornerShape(10.dp)).background(MaterialTheme.colorScheme.surface)
                            .border(androidx.compose.foundation.BorderStroke(1.dp, col.copy(alpha = .5f)), RoundedCornerShape(10.dp))
                            .clickable { vibrate(ctx, 15); onCatalog(name, listOf(name), name, Catalog.WEAPON_OFFSET[cat] ?: 0) }
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        WeaponIcon(icon, col, Modifier.width(28.dp).height(13.dp))
                        Text(name, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
                    }
                }
            }
            SectionHeader(tr("search"))
            if (recents.isNotEmpty()) FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                recents.forEach { r -> Chip("↗ $r") { onCatalog(tr("savedT"), listOf(r), r, 0) } }
            }
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Catalog.BRANDS.forEach { b -> Chip(b) { onBrand(b) } }
                Chip(tr("more")) { onMore() }
            }
            SectionHeader(tr("or"))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                SheetButton(tr("saved"), Modifier.weight(1f)) { onMenu("saved") }
                SheetButton(tr("share"), Modifier.weight(1f)) { onMenu("share") }
            }
            SheetButton(tr("namesBtn")) { onMenu("names") }
            SheetButton(CHAT_LABEL) { onMenu("chat") }
            SheetButton(BOOST_LABEL) { onMenu("boost") }
            PrimaryButton("⚡ $COMMUNITY_LABEL") { onMenu("community") }
            Text(tr("madeBy") + " JMZ", Modifier.align(Alignment.CenterHorizontally), fontSize = 12.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = .5f))
            Text(tr("devBy") + " JMZ", Modifier.align(Alignment.CenterHorizontally), fontSize = 12.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = .5f))
            Spacer(Modifier.navigationBarsPadding())
        }
    }
}

@Composable
fun HeroBtn(label: String, onClick: () -> Unit) {
    Box(Modifier.size(40.dp).clip(CircleShape).background(Color(0x99000000)).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Text(label, color = Color.White, fontSize = 18.sp)
    }
}

// ---------------------------------------------------------------- GENERADOR
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun GenScreen(
    prefill: String, onBack: () -> Unit, onAddRecent: () -> Unit, onFavSave: (String, Boolean) -> Unit,
    onNames: () -> Unit
) {
    val ctx = LocalContext.current
    var model by remember { mutableStateOf(prefill) }
    var dpi by remember { mutableStateOf(false) }
    ScreenFrame(tt("gen"), onBack) {
        OutlinedTextField(model, { model = it }, singleLine = true, modifier = Modifier.fillMaxWidth(), placeholder = { Text(tr("model")) })
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip(tr("noDpi"), !dpi) { dpi = false }
            Chip(tr("withDpi"), dpi) { dpi = true }
        }
        tiersOf(model.trim(), dpi).forEach { (id, dp, st) -> TierCard(id, dp, st) }
        PrimaryButton(tr("copy")) {
            val t = SensiEngine.buildConfigText(model)
            if (t == null) toast(ctx, tr("enter")) else { copyText(ctx, t); toast(ctx, tr("copied")); Store.addRecent(ctx, model); onAddRecent(); vibrate(ctx, 50) }
        }
        SheetButton(tr("saveImg")) {
            if (model.isBlank()) toast(ctx, tr("enter")) else {
                toast(ctx, tr("saving")); val err = saveConfigImage(ctx, model); toast(ctx, err ?: tr("savedOk"))
            }
        }
        SheetButton(tr("favBtn")) { if (model.isBlank()) toast(ctx, tr("enter")) else onFavSave(model.trim(), dpi) }
        SheetButton(tr("namesBtn")) { onNames() }
        SheetButton(tr("shareBtn")) {
            val t = SensiEngine.buildConfigText(model)
            if (t == null) toast(ctx, tr("enter")) else { shareText(ctx, "SensiPro · " + model.trim(), t + "\n\n" + xt("shareVia")); Store.addRecent(ctx, model); onAddRecent() }
        }
    }
}

// ---------------------------------------------------------------- CATÁLOGO
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CatalogScreen(title: String, list: List<String>, first: String, offset: Int, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var sel by remember { mutableStateOf(first) }
    var dpi by remember { mutableStateOf(false) }
    ScreenFrame(title, onBack) {
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            list.forEach { m -> Chip(m, m == sel) { sel = m } }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip(tr("noDpi"), !dpi) { dpi = false }
            Chip(tr("withDpi"), dpi) { dpi = true }
        }
        val tiers = tiersOf(sel, dpi, offset)
        tiers.forEach { (id, dp, st) -> TierCard(id, dp, st) }
        PrimaryButton(tr("copy")) {
            var text = "📱 " + sel.uppercase() + "\n" + (if (dpi) tr("withDpi") else tr("noDpi"))
            tiers.forEach { (id, dp, st) ->
                val h = when (id) { "alta" -> tr("hHigh"); "media" -> tr("hMid"); else -> tr("hLow") }
                text += "\n\n" + h + (if (dp != null) "\n$dp" else "") + "\n" + st.joinToString("\n") { it.first + ": " + it.second }
            }
            copyText(ctx, text); toast(ctx, tr("copied"))
        }
    }
}

// ---------------------------------------------------------------- MÁS DISPOSITIVOS
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MoreScreen(onBack: () -> Unit, onOpen: (String, List<String>, String) -> Unit) {
    var q by remember { mutableStateOf("") }
    ScreenFrame("MÁS DISPOSITIVOS", onBack) {
        OutlinedTextField(q, { q = it }, singleLine = true, modifier = Modifier.fillMaxWidth(), placeholder = { Text("🔍 Buscar dispositivo...") })
        var found = 0
        Models.ALL.forEach { (b, all) ->
            val l = all.filter { fullName(b, it).lowercase().contains(q.trim().lowercase()) }
            if (l.isEmpty()) return@forEach
            found += l.size
            SectionHeader(b)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                l.forEach { m -> Chip(m) { onOpen(b, all.map { fullName(b, it) }, fullName(b, m)) } }
            }
        }
        if (found == 0) Text("No se encontraron dispositivos", color = MaterialTheme.colorScheme.onBackground.copy(alpha = .6f))
    }
}

// ---------------------------------------------------------------- FUNCIONES: tip / reto / ayuda / calibrar / optimizar
@Composable
fun FeatScreen(k: String, onBack: () -> Unit, onSupport: () -> Unit, onMine: () -> Unit) {
    ScreenFrame(tt(k), onBack) {
        when (k) {
            "tip" -> TipView()
            "ch" -> ChView()
            "help" -> HelpView(onSupport)
            "cal" -> CalView(onMine)
            "opt" -> OptView()
        }
    }
}

@Composable
fun ColumnScope.TipView() {
    val ctx = LocalContext.current
    var off by remember { mutableStateOf(0) }
    val l = EsData.TIPS; val txt = l[((Store.dayNum() + off) % l.size).toInt()]
    CardBox { Text("💡", fontSize = 36.sp); Text(txt, fontSize = 16.sp, color = MaterialTheme.colorScheme.onSurface) }
    PrimaryButton(tt("tipNew")) { off++ }
    SheetButton(tt("tipCopy")) { copyText(ctx, txt); toast(ctx, tt("copied")) }
}

@Composable
fun ColumnScope.ChView() {
    val ctx = LocalContext.current
    var st by remember { mutableStateOf(Store.ch(ctx)) }
    val L = EsData.CHALL; val k = Store.dayKey(); val n = Store.dayNum()
    val idx = remember(n) {
        val r = (0..2).map { ((n * 3 + it * 7) % L.size).toInt() }.distinct().toMutableList()
        var i = 0; while (r.size < 3) { if (!r.contains(i)) r.add(i); i++ }; r.toList()
    }
    val dn = if (st.d == k) st.done else emptySet()
    CardBox { Text(tt("chIntro"), color = MaterialTheme.colorScheme.onSurface); Text(tt("streak") + ": " + st.streak + " " + tt("days"), fontWeight = FontWeight.Bold, color = SensiColors.Primary) }
    CardBox {
        Text(tt("today"), fontWeight = FontWeight.Bold, color = SensiColors.Primary)
        idx.forEach { i ->
            Row(Modifier.fillMaxWidth().clickable {
                val s = Store.ch(ctx); val cur = if (s.d == k) s.done else emptySet()
                val d = if (cur.contains(i)) cur - i else cur + i
                val was = s.d == k && s.complete; val now = idx.all { d.contains(it) }
                var sk = s.streak
                if (now && !was) sk = (if (s.last == n - 1) sk else 0) + 1 else if (!now && was) sk = maxOf(0, sk - 1)
                val ns = Store.Ch(k, d, now, sk, if (now) n else (if (was) s.prevLast else s.last), s.last)
                Store.saveCh(ctx, ns); st = ns
            }, verticalAlignment = Alignment.CenterVertically) {
                Checkbox(dn.contains(i), onCheckedChange = null)
                Spacer(Modifier.width(8.dp)); Text(L[i], color = MaterialTheme.colorScheme.onSurface)
            }
        }
    }
    if (idx.all { dn.contains(it) }) CardBox { Text("🏆 " + tt("chDone"), fontWeight = FontWeight.Bold, color = SensiColors.TierMedia) }
}

@Composable
fun ColumnScope.HelpView(onSupport: () -> Unit) {
    Text(tt("faqIntro"), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
    EsData.FAQ.forEach { (q, a) ->
        var open by remember { mutableStateOf(false) }
        CardBox(Modifier.clickable { open = !open }) {
            Text((if (open) "▾ " else "▸ ") + q, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
            if (open) Text(a, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .8f))
        }
    }
    SheetButton(tt("contact")) { onSupport() }
}

fun refreshHz(ctx: Context): String {
    val hz = try {
        @Suppress("DEPRECATION") val d: Display = (ctx.getSystemService(Context.WINDOW_SERVICE) as android.view.WindowManager).defaultDisplay
        d.refreshRate
    } catch (e: Exception) { return tt("na") }
    return listOf(30, 60, 72, 90, 120, 144, 165).minByOrNull { kotlin.math.abs(it - hz) }.toString() + " Hz"
}

@Composable
fun ColumnScope.CalView(onMine: () -> Unit) {
    val ctx = LocalContext.current
    var last by remember { mutableStateOf(Store.cal(ctx)) }
    var running by remember { mutableStateOf(false) }
    var round by remember { mutableStateOf(0) }
    var dot by remember { mutableStateOf<Pair<Float, Float>?>(null) }
    var areaW by remember { mutableStateOf(0) }; var areaH by remember { mutableStateOf(0) }
    var msg by remember { mutableStateOf("") }
    val rad = 30f * ctx.resources.displayMetrics.density
    var hits by remember { mutableStateOf(0) }; var sumRt by remember { mutableStateOf(0L) }; var sumErr by remember { mutableStateOf(0f) }
    var t0 by remember { mutableStateOf(0L) }; var active by remember { mutableStateOf(false) }
    var trigger by remember { mutableStateOf(0) }

    CardBox { Text(tt("calIntro"), color = MaterialTheme.colorScheme.onSurface) }
    last?.let { r ->
        val L = when (r.lv) { "H" -> "lvH"; "M" -> "lvM"; else -> "lvL" }
        CardBox {
            Text(tt("lvl") + ": " + tt(L), fontWeight = FontWeight.Bold, color = SensiColors.Primary)
            StatRow(tt("hits"), r.hits.toString() + "/8"); StatRow(tt("react"), r.rt.toString() + " ms")
            StatRow(tt("err"), r.err.toString() + " px"); StatRow(tt("touch"), when (r.tp) { 5 -> "5 o más"; 2 -> "2 o más"; else -> r.tp.toString() }); StatRow(tt("hz"), r.hz)
            Text(tt(L + "t"), fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .8f))
            SheetButton(tt("seeSensi")) { onMine() }
        }
    }
    Box(
        Modifier.fillMaxWidth().height(320.dp).clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.surface)
            .border(androidx.compose.foundation.BorderStroke(1.dp, SensiColors.GlassBorder), RoundedCornerShape(16.dp))
            .onSizeChanged { areaW = it.width; areaH = it.height }
            .pointerInput(running) {
                detectTapGestures(onPress = { o ->
                    val d = dot
                    if (active && d != null) {
                        active = false
                        sumRt += System.currentTimeMillis() - t0
                        val dist = hypot(o.x - d.first, o.y - d.second); sumErr += dist; if (dist <= rad) hits++
                        round++; dot = null; trigger++
                    }
                })
            }
    ) {
        dot?.let { d -> Box(Modifier.offset { IntOffset((d.first - rad).toInt(), (d.second - rad).toInt()) }.size((rad * 2 / ctx.resources.displayMetrics.density).dp).clip(CircleShape).background(SensiColors.Primary)) }
        Text(msg, Modifier.align(Alignment.Center), color = MaterialTheme.colorScheme.onSurface.copy(alpha = .7f))
    }
    LaunchedEffect(trigger, running) {
        if (!running) return@LaunchedEffect
        if (round >= 8) {
            msg = tt("measuring"); val hz = refreshHz(ctx)
            val rt = (sumRt / 8).toInt(); val err = (sumErr / 8).toInt()
            val lv = if (hits >= 7 && rt < 600) "H" else if (hits >= 5 && rt < 900) "M" else "L"
            val tp = if (ctx.packageManager.hasSystemFeature(PackageManager.FEATURE_TOUCHSCREEN_MULTITOUCH_JAZZHAND)) 5
                else if (ctx.packageManager.hasSystemFeature(PackageManager.FEATURE_TOUCHSCREEN_MULTITOUCH_DISTINCT)) 2 else 1
            val r = Store.Cal(hits, rt, err, tp, hz, lv); Store.saveCal(ctx, r); last = r; msg = ""; running = false; return@LaunchedEffect
        }
        if (round > 0) delay(250)
        val w = areaW.toFloat(); val h = areaH.toFloat()
        dot = Pair(rad + Random.nextFloat() * (w - 2 * rad), rad + Random.nextFloat() * (h - 2 * rad))
        msg = tt("round") + " " + (round + 1) + "/8"; t0 = System.currentTimeMillis(); active = true
    }
    PrimaryButton(tt(if (last != null) "again" else "start"), enabled = !running) {
        hits = 0; sumRt = 0; sumErr = 0f; round = 0; running = true; trigger++
    }
}

@Composable
fun ColumnScope.OptView() {
    val ctx = LocalContext.current
    var done by remember { mutableStateOf(Store.optDone(ctx)) }
    val L = EsData.OPT
    CardBox {
        Text(tt("optIntro"), color = MaterialTheme.colorScheme.onSurface)
        Text(tt("optScore") + ": " + Math.round(done.size.toFloat() / L.size * 100) + " %", fontWeight = FontWeight.Bold, color = SensiColors.Primary)
    }
    // Análisis automático con APIs reales de Android
    val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
    val gb = Math.round(mi.totalMem / 1073741824.0).toInt()
    val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
    val bat = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
    val charging = bm.isCharging
    val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    val caps = cm.getNetworkCapabilities(cm.activeNetwork)
    val net = when {
        caps == null -> null
        caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "WIFI"
        caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "MÓVIL"
        else -> "RED"
    }
    val hz = refreshHz(ctx)
    CardBox {
        Text(tt("optAuto"), fontWeight = FontWeight.Bold, color = SensiColors.Primary)
        StatRow(tt("ram"), "≈ $gb GB"); Text(if (gb <= 3) tt("lowRam") else tt("okRam"), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .7f))
        StatRow(tt("cores"), Runtime.getRuntime().availableProcessors().toString())
        if (bat in 0..100) { StatRow(tt("bat"), "$bat %"); Text(if (bat < 20 && !charging) tt("lowBat") else tt("okBat"), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .7f)) }
        if (net != null) { StatRow(tt("net"), net); Text(tt("okNet"), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .7f)) }
        StatRow("Ahorro de batería", if ((ctx.getSystemService(Context.POWER_SERVICE) as android.os.PowerManager).isPowerSaveMode) "Activado" else "Desactivado")
        StatRow(tt("hz"), hz); Text(if ((hz.substringBefore(" ").toIntOrNull() ?: 60) <= 60) tt("hz60") else tt("hzOk"), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .7f))
    }
    StorageCard()
    CardBox {
        L.forEachIndexed { i, x ->
            Row(Modifier.fillMaxWidth().clickable {
                val s = if (done.contains(i)) done - i else done + i; Store.setOpt(ctx, s); done = s
            }, verticalAlignment = Alignment.CenterVertically) {
                Checkbox(done.contains(i), onCheckedChange = null); Spacer(Modifier.width(8.dp)); Text(x, color = MaterialTheme.colorScheme.onSurface)
            }
            OPT_ACTIONS[i]?.let { a -> SheetButton(a.first) { if (!openSettings(ctx, a.second)) toast(ctx, "Este dispositivo no permite abrir esa pantalla de ajustes.") } }
        }
    }
}

// MI DISPOSITIVO: ver DeviceInfo.kt
