package com.jmz.sensipro.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.MediaStore
import android.widget.Toast
import com.jmz.sensipro.data.EsData
import com.jmz.sensipro.data.SensiEngine

fun tr(k: String): String = EsData.I18N[k] ?: k
fun xt(k: String): String = EsData.X[k] ?: k
fun tt(k: String): String = EsData.T[k] ?: k

fun toast(c: Context, m: String) = Toast.makeText(c, m, Toast.LENGTH_SHORT).show()

fun copyText(c: Context, t: String) {
    (c.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("SensiPro", t))
}

@Suppress("DEPRECATION")
fun vibrate(c: Context, ms: Long) {
    try { (c.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator).vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE)) } catch (e: Exception) {}
}

fun shareText(c: Context, subject: String, text: String) {
    val i = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_SUBJECT, subject); putExtra(Intent.EXTRA_TEXT, text) }
    c.startActivity(Intent.createChooser(i, subject).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}

const val SUPPORT_MAIL = "jmnzgln@gmail.com"
const val SUPPORT_SUBJ = "Soporte SensiPro"

fun supportMail(c: Context) {
    val i = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:$SUPPORT_MAIL?subject=" + Uri.encode(SUPPORT_SUBJ)))
    try { c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { toast(c, "No hay ninguna app de correo instalada. Copia el correo o usa Gmail web.") }
}

fun supportGmail(c: Context) {
    val u = "https://mail.google.com/mail/?view=cm&to=$SUPPORT_MAIL&su=" + Uri.encode(SUPPORT_SUBJ)
    try { c.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    catch (e: Exception) { toast(c, "No hay ningún navegador disponible para abrir Gmail web.") }
}

/** Equivalente a saveGen(): dibuja la configuración en un Bitmap 1080 px y la guarda en Imágenes. */
/** Devuelve null si se guardó de verdad; si no, el motivo real del fallo. */
fun saveConfigImage(c: Context, model: String): String? {
    val m = model.trim(); if (m.isEmpty()) return tr("enter")
    val seed = SensiEngine.generateHash(m.lowercase()); val f = SensiEngine.modelFlags(m)
    val rows = SensiEngine.TIERS.size * 7
    val W = 1080; val H = 300 + SensiEngine.TIERS.size * 520
    val bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888); val cv = Canvas(bmp)
    cv.drawColor(0xFF050508.toInt())
    val p = Paint(Paint.ANTI_ALIAS_FLAG)
    p.color = 0xFFFF2D3D.toInt(); p.textSize = 90f; p.typeface = Typeface.DEFAULT_BOLD; cv.drawText("SENSIPRO", 60f, 130f, p)
    p.color = 0xFFFFFFFF.toInt(); p.textSize = 52f; cv.drawText(m.uppercase().take(26), 60f, 220f, p)
    var y = 300f
    val cols = intArrayOf(0xFFFF0055.toInt(), 0xFFFFCA28.toInt(), 0xFFFF2D3D.toInt())
    SensiEngine.TIERS.forEachIndexed { i, t ->
        val s = SensiEngine.statsFor(seed, t, false, f)
        p.color = cols[i]; p.textSize = 46f; cv.drawText(t.label, 60f, y + 40f, p)
        var yy = y + 100f
        s.asPairs().forEach { (k, v) ->
            p.color = 0xFFBBBBBB.toInt(); p.textSize = 38f; p.typeface = Typeface.DEFAULT; cv.drawText(k, 80f, yy, p)
            p.color = 0xFFFFFFFF.toInt(); p.typeface = Typeface.DEFAULT_BOLD; cv.drawText(v.toString(), 900f, yy, p); yy += 62f
        }
        y += 520f
    }
    p.color = 0x88FFFFFF.toInt(); p.textSize = 30f; cv.drawText("SensiPro · JMZ", 60f, H - 40f, p)
    return try {
        val v = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "SensiPro_${System.currentTimeMillis()}.png")
            put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/SensiPro")
        }
        val uri = c.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v) ?: return "Android no permitió crear el archivo en Imágenes"
        c.contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        null
    } catch (e: Exception) { "No se pudo guardar la imagen: " + (e.message ?: "Android lo impidió") }
}

fun fullName(b: String, m: String) = if (b == "APPLE") m else "$b $m"

const val COMMUNITY_LABEL = "Únete a la comunidad"
private const val COMMUNITY_URL = "https://whatsapp.com/channel/0029VbB64Hj9cDDSjR4AD33D"

/** Abre el enlace de la comunidad: en la app correspondiente si está instalada; si no, en el navegador. */
fun openCommunity(c: Context) {
    val i = Intent(Intent.ACTION_VIEW, Uri.parse(COMMUNITY_URL)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    try { c.startActivity(i) } catch (e: Exception) {
        copyText(c, COMMUNITY_URL)
        toast(c, "No hay navegador disponible. Enlace copiado.")
    }
}
