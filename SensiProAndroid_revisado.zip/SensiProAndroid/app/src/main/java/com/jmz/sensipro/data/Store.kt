package com.jmz.sensipro.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar
import java.util.TimeZone

/** Equivalente a `store` (localStorage) del original; mismas claves: ff_recent, ff_favs, sp_cal, sp_opt, sp_ch... */
object Store {
    private fun sp(c: Context) = c.getSharedPreferences("sensipro", Context.MODE_PRIVATE)
    fun get(c: Context, k: String): String? = sp(c).getString(k, null)
    fun set(c: Context, k: String, v: String) = sp(c).edit().putString(k, v).apply()

    private fun strList(s: String?): List<String> = try {
        val a = JSONArray(s ?: "[]"); (0 until a.length()).map { a.getString(it) }
    } catch (e: Exception) { emptyList() }

    fun recents(c: Context) = strList(get(c, "ff_recent"))
    fun addRecent(c: Context, m: String) {
        val x = m.trim().uppercase()
        set(c, "ff_recent", JSONArray((listOf(x) + recents(c).filter { it != x }).take(8)).toString())
    }

    data class Fav(val name: String, val model: String, val dpi: Boolean)
    fun favs(c: Context): List<Fav> = try {
        val a = JSONArray(get(c, "ff_favs") ?: "[]")
        (0 until a.length()).map { val o = a.getJSONObject(it); Fav(o.getString("name"), o.getString("model"), o.optBoolean("dpi")) }
    } catch (e: Exception) { emptyList() }
    fun saveFavs(c: Context, l: List<Fav>) {
        val a = JSONArray(); l.take(30).forEach { a.put(JSONObject().put("name", it.name).put("model", it.model).put("dpi", it.dpi)) }
        set(c, "ff_favs", a.toString())
    }

    /** Usos disponibles de «Generar sensibilidad personalizada» (se recargan con un anuncio con recompensa). */
    const val GEN_PER_AD = 5
    fun genCredits(c: Context): Int = get(c, "sp_gen_credits")?.toIntOrNull()?.coerceAtLeast(0) ?: 0
    fun setGenCredits(c: Context, n: Int) = set(c, "sp_gen_credits", n.coerceAtLeast(0).toString())

    fun policyAccepted(c: Context) = get(c, "ff_policy") == POLICY_VER
    fun acceptPolicy(c: Context) = set(c, "ff_policy", POLICY_VER)
    const val POLICY_VER = "2026-10"

    fun optDone(c: Context): Set<Int> = strList(get(c, "sp_opt")).mapNotNull { it.toIntOrNull() }.toSet()
    fun setOpt(c: Context, s: Set<Int>) = set(c, "sp_opt", JSONArray(s.map { it.toString() }).toString())

    data class Cal(val hits: Int, val rt: Int, val err: Int, val tp: Int, val hz: String, val lv: String)
    fun cal(c: Context): Cal? = try {
        val o = JSONObject(get(c, "sp_cal") ?: return null)
        Cal(o.getInt("hits"), o.getInt("rt"), o.getInt("err"), o.getInt("tp"), o.getString("hz"), o.getString("lv"))
    } catch (e: Exception) { null }
    fun saveCal(c: Context, r: Cal) = set(c, "sp_cal", JSONObject().put("hits", r.hits).put("rt", r.rt)
        .put("err", r.err).put("tp", r.tp).put("hz", r.hz).put("lv", r.lv).toString())

    data class Ch(val d: String, val done: Set<Int>, val complete: Boolean, val streak: Int, val last: Long, val prevLast: Long)
    fun ch(c: Context): Ch = try {
        val o = JSONObject(get(c, "sp_ch") ?: "{}")
        val a = o.optJSONArray("done") ?: JSONArray()
        Ch(o.optString("d"), (0 until a.length()).map { a.getInt(it) }.toSet(), o.optBoolean("complete"),
            o.optInt("streak"), o.optLong("last", -999), o.optLong("prevLast", -999))
    } catch (e: Exception) { Ch("", emptySet(), false, 0, -999, -999) }
    fun saveCh(c: Context, s: Ch) = set(c, "sp_ch", JSONObject().put("d", s.d).put("done", JSONArray(s.done.toList()))
        .put("complete", s.complete).put("streak", s.streak).put("last", s.last).put("prevLast", s.prevLast).toString())

    fun dayKey(): String { val d = Calendar.getInstance(); return "${d.get(Calendar.YEAR)}-${d.get(Calendar.MONTH) + 1}-${d.get(Calendar.DAY_OF_MONTH)}" }
    fun dayNum(): Long { val now = System.currentTimeMillis(); return (now + TimeZone.getDefault().getOffset(now)) / 86_400_000L }
}
