package com.jmz.sensipro.ui

import android.app.ActivityManager
import android.content.Context
import android.os.Debug
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

const val BOOST_LABEL = "🚀 OPTIMIZADOR RAM / BOOSTER"

private data class Ram(val total: Long, val avail: Long, val threshold: Long, val low: Boolean) {
    val used get() = (total - avail).coerceAtLeast(0)
}

/** Lectura real de la RAM con ActivityManager.getMemoryInfo(). */
private fun readRam(ctx: Context): Ram {
    val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
    return Ram(mi.totalMem, mi.availMem, mi.threshold, mi.lowMemory)
}

/** Memoria propia de SensiPro (PSS) en bytes, medida con Debug.getMemoryInfo(). */
private fun ownPss(): Long = try {
    Debug.MemoryInfo().also { Debug.getMemoryInfo(it) }.totalPss.toLong() * 1024
} catch (e: Exception) { 0L }

private data class BoostResult(
    val cacheBefore: Long, val cacheAfter: Long,
    val pssBefore: Long, val pssAfter: Long,
    val availBefore: Long, val availAfter: Long
)

/** Acciones reales y permitidas: solo tocan lo que pertenece a SensiPro. No cierra ni toca otras apps. */
private fun runBoost(ctx: Context): BoostResult {
    val ramB = readRam(ctx); val pssB = ownPss()
    val dirs = listOfNotNull(ctx.cacheDir, ctx.externalCacheDir)
    val cb = dirs.sumOf { dirSize(it) }
    dirs.forEach { d -> d.listFiles()?.forEach { it.deleteRecursively() } }
    val ca = dirs.sumOf { dirSize(it) }
    System.gc()                       // solo una petición: Android decide si recolecta
    Thread.sleep(600)
    return BoostResult(cb, ca, pssB, ownPss(), ramB.avail, readRam(ctx).avail)
}

private fun signed(d: Long): String = (if (d > 0) "+" else if (d < 0) "−" else "") + fmtB(kotlin.math.abs(d))

@Composable
fun BoosterScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var ram by remember { mutableStateOf(readRam(ctx)) }
    var stamp by remember { mutableStateOf(System.currentTimeMillis()) }
    var running by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<BoostResult?>(null) }
    val dim = MaterialTheme.colorScheme.onSurface.copy(alpha = .7f)

    LaunchedEffect(Unit) {
        while (true) { delay(2000); ram = readRam(ctx); stamp = System.currentTimeMillis() }
    }

    ScreenFrame("🚀 OPTIMIZADOR RAM", onBack) {
        CardBox {
            Text("🧠 MEMORIA RAM (datos reales de Android)", fontWeight = FontWeight.Bold, color = SensiColors.Primary)
            val frac = if (ram.total > 0) (ram.used.toFloat() / ram.total).coerceIn(0f, 1f) else 0f
            StatRow("Total", fmtB(ram.total))
            StatRow("Disponible", fmtB(ram.avail))
            StatRow("Utilizada", "${fmtB(ram.used)} (${Math.round(frac * 100)} %)")
            Box(Modifier.fillMaxWidth().height(12.dp).clip(RoundedCornerShape(6.dp)).background(MaterialTheme.colorScheme.onSurface.copy(alpha = .12f))) {
                Box(Modifier.fillMaxWidth(frac).fillMaxHeight().background(Brush.horizontalGradient(listOf(SensiColors.Primary, SensiColors.Accent))))
            }
            StatRow("Umbral de memoria baja", fmtB(ram.threshold))
            StatRow("Sistema con poca memoria", if (ram.low) "Sí" else "No")
            StatRow("Memoria de SensiPro", ownPss().let { if (it > 0) fmtB(it) else NA })
            Text("Se actualiza cada 2 s · última lectura ${SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(stamp))}", fontSize = 11.sp, color = dim)
        }

        PrimaryButton(
            if (running) "OPTIMIZANDO…" else "OPTIMIZAR",
            Modifier.fillMaxWidth().height(76.dp).alpha(if (running) .6f else 1f), enabled = !running
        ) {
            running = true
            scope.launch {
                try {
                    result = withContext(Dispatchers.IO) { runBoost(ctx) }
                    ram = readRam(ctx); stamp = System.currentTimeMillis()
                } catch (e: Exception) {
                    toast(ctx, "No se pudo completar la optimización: " + (e.message ?: "error"))
                } finally { running = false }
            }
        }

        result?.let { r ->
            CardBox {
                Text("RESULTADO (mediciones reales)", fontWeight = FontWeight.Bold, color = SensiColors.Primary)
                StatRow("Caché de SensiPro borrada", if (r.cacheBefore == 0L) "no había" else fmtB((r.cacheBefore - r.cacheAfter).coerceAtLeast(0)))
                StatRow("Memoria de SensiPro", "${fmtB(r.pssBefore)} → ${fmtB(r.pssAfter)}")
                StatRow("RAM disponible del sistema", "${fmtB(r.availBefore)} → ${fmtB(r.availAfter)} (${signed(r.availAfter - r.availBefore)})")
                Text(
                    "Se pidió a Android recolectar la memoria no usada de SensiPro (no está garantizado que lo haga). " +
                        "La RAM disponible del sistema cambia sola por lo que hacen otras apps, así que la diferencia puede ser positiva, cero o negativa y no se debe a una limpieza de otras apps.",
                    fontSize = 12.sp, color = dim
                )
            }
        }

        CardBox {
            Text("🎮 ACCESOS ÚTILES PARA JUGAR", fontWeight = FontWeight.Bold, color = SensiColors.Primary)
            val go = { label: String, acts: List<String> ->
                if (!openSettings(ctx, acts)) toast(ctx, "Este dispositivo no permite abrir: $label")
            }
            SheetButton("📲 LISTA DE APPS (cierra a mano las que no uses)") { go("lista de apps", listOf(Settings.ACTION_APPLICATION_SETTINGS)) }
            SheetButton("🔕 NO MOLESTAR (menos avisos mientras juegas)") { go("No molestar", listOf("android.settings.ZEN_MODE_PRIORITY_SETTINGS", Settings.ACTION_SOUND_SETTINGS)) }
            SheetButton("🔋 AHORRO DE BATERÍA (limita el rendimiento si está activo)") { go("ahorro de batería", listOf(Settings.ACTION_BATTERY_SAVER_SETTINGS)) }
            SheetButton("🖥️ PANTALLA (brillo y tasa de refresco)") { go("pantalla", listOf(Settings.ACTION_DISPLAY_SETTINGS)) }
        }

        CardBox {
            Text("ℹ️ LO QUE ANDROID NO PERMITE", fontWeight = FontWeight.Bold, color = SensiColors.Primary)
            Text(
                "• Una app no puede cerrar ni limpiar otras apps ni liberar su RAM; SensiPro no lo intenta.\n" +
                    "• Android administra la RAM por sí mismo: la memoria libre sin usar se desperdicia, y cerrar apps suele hacer que vuelvan a abrirse y gasten más.\n" +
                    "• Optimizar no garantiza más FPS: el rendimiento depende del equipo, la temperatura, la batería y el juego.",
                fontSize = 12.sp, color = dim
            )
        }
    }
}
