package com.jmz.sensipro.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.jmz.sensipro.data.EsData
import com.jmz.sensipro.data.Models
import com.jmz.sensipro.data.Store
import kotlinx.coroutines.delay

sealed interface Screen {
    data object Home : Screen
    data class Gen(val prefill: String) : Screen
    data class Feat(val k: String) : Screen
    data object More : Screen
    data object Dev : Screen
    data object Chat : Screen
    data object Boost : Screen
    data class Cat(val title: String, val list: List<String>, val first: String, val offset: Int) : Screen
}

sealed interface Dlg {
    data class Info(val k: String) : Dlg
    data object Settings : Dlg
    data object Support : Dlg
    data object Names : Dlg
    data object GenLock : Dlg
    data class Fav(val model: String, val dpi: Boolean) : Dlg
    data class Policy(val lock: Boolean) : Dlg
}

@Composable
fun SheetDialog(title: String, onClose: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Dialog(onDismissRequest = onClose) {
        Column(
            Modifier.fillMaxWidth().heightIn(max = 600.dp).clip16().background(MaterialTheme.colorScheme.surface).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(title, fontSize = 17.sp, fontWeight = FontWeight.Bold, color = SensiColors.Primary)
            Column(Modifier.weight(1f, fill = false).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp), content = content)
        }
    }
}

private fun Modifier.clip16(): Modifier = this.clip(RoundedCornerShape(18.dp))

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun App(dark: Boolean, onToggleTheme: () -> Unit, onToggleFs: () -> Unit, onExit: () -> Unit) {
    val ctx = LocalContext.current
    val stack = remember { mutableStateListOf<Screen>(Screen.Home) }
    var dlg by remember { mutableStateOf<Dlg?>(if (Store.policyAccepted(ctx)) null else Dlg.Policy(true)) }
    var rv by remember { mutableStateOf(0) }
    var splash by remember { mutableStateOf(true) }
    var progress by remember { mutableStateOf(0) }

    LaunchedEffect(Unit) { while (progress < 100) { delay(100); progress = minOf(100, progress + 12) }; delay(150); splash = false }
    BackHandler(enabled = dlg != null || stack.size > 1) { if (dlg != null) dlg = null else stack.removeAt(stack.lastIndex) }

    fun push(s: Screen) { stack.add(s) }
    fun pop() { if (stack.size > 1) stack.removeAt(stack.lastIndex) }
    fun menu(k: String) {
        when (k) {
            "dev" -> push(Screen.Dev)
            "chat" -> push(Screen.Chat)
            "boost" -> push(Screen.Boost)
            "req" -> dlg = Dlg.Support
            "apps" -> toast(ctx, tr("soon"))
            "share" -> shareText(ctx, "SensiPro", "SensiPro - " + tr("search"))
            "set" -> dlg = Dlg.Settings
            "community" -> openCommunity(ctx)
            "names" -> dlg = Dlg.Names
            "priv" -> dlg = Dlg.Policy(false)
            else -> dlg = Dlg.Info(k)
        }
    }
    // «Generar sensibilidad personalizada»: cada entrada gasta 1 uso; sin usos hay que ver un anuncio con recompensa (+5).
    fun startGen(prefill: String) {
        val n = Store.genCredits(ctx)
        if (n > 0) { Store.setGenCredits(ctx, n - 1); push(Screen.Gen(prefill)) } else dlg = Dlg.GenLock
    }
    fun openCat(t: String, l: List<String>, f: String, o: Int) { dlg = null; push(Screen.Cat(t, l, f, o)) }

    if (splash) {
        Box(Modifier.fillMaxSize().background(SensiColors.BgDark), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("JMZ", color = SensiColors.Primary, fontSize = 44.sp, fontWeight = FontWeight.Black)
                Text("${tr("loading")} $progress%", color = Color.White.copy(alpha = .7f), fontSize = 13.sp)
            }
        }
        return
    }

    when (val s = stack.last()) {
        Screen.Home -> HomeScreen(
            dark, onToggleTheme, onToggleFs, { startGen(it) }, { k -> if (k == "dev") push(Screen.Dev) else push(Screen.Feat(k)) },
            { b -> openCat(b, (Models.SHORT[b] ?: emptyList()).map { fullName(b, it) }, fullName(b, Models.SHORT[b]?.firstOrNull() ?: ""), 0) },
            { push(Screen.More) }, { t, l, f, o -> openCat(t, l, f, o) }, { menu(it) }, rv
        )
        is Screen.Gen -> GenScreen(s.prefill, { pop() }, { rv++ }, { m, d -> dlg = Dlg.Fav(m, d) }, { dlg = Dlg.Names })
        is Screen.Feat -> FeatScreen(s.k, { pop() }, { dlg = Dlg.Support }) {
            val b = android.os.Build.MANUFACTURER; val m = android.os.Build.MODEL
            val full = ((if (!m.lowercase().startsWith(b.lowercase())) "$b " else "") + m)
            openCat(full.uppercase(), listOf(full), full, 0)
        }
        Screen.More -> MoreScreen({ pop() }) { b, l, f -> openCat(b, l, f, 0) }
        Screen.Chat -> ChatScreen { pop() }
        Screen.Boost -> BoosterScreen { pop() }
        Screen.Dev -> DevScreen({ pop() }) { full -> openCat(full, listOf(full), full, 0) }
        is Screen.Cat -> CatalogScreen(s.title, s.list, s.first, s.offset) { pop() }
    }

    when (val d = dlg) {
        null -> {}
        is Dlg.Info -> {
            val map = mapOf("help" to ("helpT" to "helpB"), "about" to ("aboutT" to "aboutB"), "saved" to ("savedT" to null))
            val (tk, bk) = map[d.k] ?: ("helpT" to "helpB")
            SheetDialog(tr(tk), { dlg = null }) {
                val rec = Store.recents(ctx); var favs by remember { mutableStateOf(Store.favs(ctx)) }
                if (bk != null) Text(tr(bk), color = MaterialTheme.colorScheme.onSurface)
                else {
                    if (rec.isEmpty() && favs.isEmpty()) Text(tr("noSaved"), color = MaterialTheme.colorScheme.onSurface)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        rec.forEach { m -> Chip("↗ $m") { openCat(tr("savedT"), listOf(m), m, 0) } }
                    }
                    if (favs.isNotEmpty()) SectionHeader(xt("favT"))
                    favs.forEachIndexed { i, f ->
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            SheetButton("⭐ ${f.name} · ${f.model}", Modifier.weight(1f)) { openCat(tr("savedT"), listOf(f.model), f.model, 0) }
                            SheetButton("✕", Modifier.width(52.dp)) { val l = favs.toMutableList(); l.removeAt(i); Store.saveFavs(ctx, l); favs = l }
                        }
                    }
                }
            }
        }
        is Dlg.Policy -> SheetDialog(xt("plT"), { if (!d.lock) dlg = null }) {
            Text(xt("policy"), fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
            if (d.lock) {
                PrimaryButton(xt("plA")) { Store.acceptPolicy(ctx); dlg = null }
                SheetButton(xt("plD")) { toast(ctx, xt("plN")); onExit() }
            } else SheetButton(xt("plC")) { dlg = null }
        }
        Dlg.Settings -> SheetDialog(tr("settings"), { dlg = null }) {
            SectionHeader(tr("lang")); Chip("Español", true) { toast(ctx, "Por ahora solo hay español; los demás idiomas aún no están portados.") }
            SheetButton(tr("full")) { onToggleFs() }
            SheetButton(tr("support")) { dlg = Dlg.Support }
        }
        Dlg.GenLock -> SheetDialog("✨ " + tr("gen"), { dlg = null }) {
            Text("Mira un anuncio completo para desbloquear ${Store.GEN_PER_AD} usos de la sensibilidad personalizada.", color = MaterialTheme.colorScheme.onSurface)
            PrimaryButton("▶ VER ANUNCIO (+${Store.GEN_PER_AD} USOS)") {
                val a = ctx as? android.app.Activity
                if (a == null) toast(ctx, "Anuncio no disponible")
                else Ads.showRewarded(a, {
                    Store.setGenCredits(ctx, Store.GEN_PER_AD - 1)   // el uso actual ya se descuenta
                    toast(ctx, "¡Listo! Tienes ${Store.GEN_PER_AD} usos"); dlg = null; push(Screen.Gen(""))
                }, { toast(ctx, "El anuncio aún no está listo, inténtalo en unos segundos") })
            }
            SheetButton(xt("plC")) { dlg = null }
        }
        Dlg.Support -> SheetDialog(tr("support"), { dlg = null }) {
            Text(tr("hint") + " " + SUPPORT_MAIL, color = MaterialTheme.colorScheme.onSurface)
            PrimaryButton(tr("mail")) { supportMail(ctx) }
            SheetButton(tr("gmail")) { supportGmail(ctx) }
            SheetButton(tr("copyMail")) { copyText(ctx, SUPPORT_MAIL); toast(ctx, tr("mailCopied")) }
        }
        Dlg.Names -> SheetDialog(xt("nmT"), { dlg = null }) {
            NamesContent()
            EsData.NAMES_FREE.forEach { (k, list) ->
                SectionHeader(xt(k))
                list.forEach { n -> SheetButton(n) { copyText(ctx, n); toast(ctx, xt("nmCopied")) } }
            }
            SectionHeader(xt("nmD"))
            EsData.NAMES_LOCKED.forEach { n -> SheetButton(n) { copyText(ctx, n); toast(ctx, xt("nmCopied")) } }
        }
        is Dlg.Fav -> {
            var name by remember { mutableStateOf(d.model.uppercase()) }
            SheetDialog(xt("fvT"), { dlg = null }) {
                OutlinedTextField(name, { name = it }, singleLine = true, placeholder = { Text(xt("fvP")) }, modifier = Modifier.fillMaxWidth())
                PrimaryButton(xt("fvS")) {
                    val n = (name.trim().ifEmpty { d.model }).take(30)
                    Store.saveFavs(ctx, listOf(Store.Fav(n, d.model, d.dpi)) + Store.favs(ctx)); dlg = null; toast(ctx, xt("fvOk"))
                }
            }
        }
    }
}
