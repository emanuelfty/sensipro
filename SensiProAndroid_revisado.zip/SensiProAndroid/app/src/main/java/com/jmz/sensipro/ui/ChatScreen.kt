package com.jmz.sensipro.ui

import androidx.activity.ComponentActivity
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.jmz.sensipro.data.ChatException
import com.jmz.sensipro.data.ChatMsg
import com.jmz.sensipro.data.ChatRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter

const val CHAT_LABEL = "💬 CHAT GLOBAL"

private enum class Conn { LOADING, OK, OFFLINE, ERROR, UNCONFIGURED }

private const val POLL_MS = 3000L
private const val MIN_GAP_MS = 2500L

@Composable
fun ChatScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val repo = remember { ChatRepository(ctx) }
    val msgs = remember { mutableStateListOf<ChatMsg>() }
    var conn by remember { mutableStateOf(if (repo.configured) Conn.LOADING else Conn.UNCONFIGURED) }
    var info by remember { mutableStateOf("") }
    var input by remember { mutableStateOf("") }
    var sending by remember { mutableStateOf(false) }
    var sendErr by remember { mutableStateOf<String?>(null) }
    var resumed by remember { mutableStateOf(true) }
    var lastSentAt by remember { mutableStateOf(0L) }
    val poke = remember { Channel<Unit>(Channel.CONFLATED) }
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    // Solo consulta al servidor mientras la app está a la vista.
    DisposableEffect(ctx) {
        val lc = (ctx as? ComponentActivity)?.lifecycle
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_RESUME) { resumed = true; poke.trySend(Unit) }
            else if (e == Lifecycle.Event.ON_PAUSE) resumed = false
        }
        lc?.addObserver(obs)
        onDispose { lc?.removeObserver(obs) }
    }

    // Recepción: pide al servidor los mensajes nuevos cada pocos segundos (con espera creciente si falla).
    LaunchedEffect(repo) {
        if (!repo.configured) return@LaunchedEffect
        var lastTs: String? = null
        var fails = 0
        while (true) {
            while (!resumed) delay(500)
            try {
                val since = lastTs
                val list = if (since == null) repo.loadRecent() else repo.loadSince(since)
                val known = msgs.map { it.id }.toHashSet()
                val fresh = list.filter { it.id !in known }
                if (fresh.isNotEmpty()) msgs.addAll(fresh)
                if (list.isNotEmpty()) lastTs = list.last().createdAt
                conn = Conn.OK; info = ""; fails = 0
            } catch (e: CancellationException) {
                throw e
            } catch (e: ChatException) {
                fails++
                conn = if (e.kind == ChatException.Kind.NETWORK) Conn.OFFLINE else Conn.ERROR
                info = e.message ?: ""
            } catch (e: Exception) {
                fails++; conn = Conn.ERROR; info = e.message ?: "Error desconocido"
            }
            val wait = if (fails == 0) POLL_MS else minOf(15_000L, POLL_MS * (fails + 1))
            withTimeoutOrNull(wait) { poke.receive() }
        }
    }

    LaunchedEffect(msgs.size) {
        val n = msgs.size
        if (n == 0) return@LaunchedEffect
        val last = listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: -1
        if (last == -1 || last >= n - 4) listState.scrollToItem(n - 1)
    }

    val trimmed = input.trim()
    val canSend = conn != Conn.UNCONFIGURED && trimmed.isNotEmpty() && !sending

    fun doSend() {
        val t = input.trim()
        if (t.isEmpty() || sending) return
        if (t.length > ChatRepository.MAX_LEN) { sendErr = "Máximo ${ChatRepository.MAX_LEN} caracteres"; return }
        if (System.currentTimeMillis() - lastSentAt < MIN_GAP_MS) { sendErr = "Espera un par de segundos entre mensajes"; return }
        sending = true; sendErr = null
        scope.launch {
            try {
                repo.send(t)               // solo llega aquí si el servidor aceptó el mensaje
                input = ""
                lastSentAt = System.currentTimeMillis()
                poke.trySend(Unit)
            } catch (e: CancellationException) {
                throw e
            } catch (e: ChatException) {
                sendErr = "No se envió: " + (e.message ?: "error")
            } catch (e: Exception) {
                sendErr = "No se envió: " + (e.message ?: "error")
            } finally {
                sending = false
            }
        }
    }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).statusBarsPadding().imePadding()) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(40.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surface).clickable(onClick = onBack),
                contentAlignment = Alignment.Center
            ) { Text("←", fontSize = 20.sp, color = MaterialTheme.colorScheme.onSurface) }
            Spacer(Modifier.width(12.dp))
            Column {
                Text(CHAT_LABEL, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = SensiColors.Primary)
                val (label, col) = when (conn) {
                    Conn.LOADING -> "Conectando…" to MaterialTheme.colorScheme.onSurface.copy(alpha = .7f)
                    Conn.OK -> "● Conectado" to Color(0xFF3DDC84)
                    Conn.OFFLINE -> "○ Sin conexión · reintentando" to SensiColors.TierMedia
                    Conn.ERROR -> "⚠ $info" to SensiColors.Primary
                    Conn.UNCONFIGURED -> "Chat no disponible" to SensiColors.TierMedia
                }
                Text(label, fontSize = 12.sp, color = col)
            }
        }

        Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp)) {
            when {
                conn == Conn.UNCONFIGURED -> CardBox(Modifier.align(Alignment.Center)) {
                    Text(
                        "El chat global no está disponible: falta configurar el servidor (ver README del proyecto, sección «Chat global»).",
                        fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface
                    )
                }
                msgs.isEmpty() && conn == Conn.LOADING -> CircularProgressIndicator(Modifier.align(Alignment.Center), color = SensiColors.Primary)
                msgs.isEmpty() && conn == Conn.OK -> Text(
                    "Aún no hay mensajes. Escribe el primero.", Modifier.align(Alignment.Center), textAlign = TextAlign.Center,
                    fontSize = 13.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = .6f)
                )
                else -> LazyColumn(state = listState, verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxSize()) {
                    items(msgs, key = { it.id }) { m -> Bubble(m, m.uid == repo.uid) }
                }
            }
        }

        if (conn != Conn.UNCONFIGURED) {
            Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                sendErr?.let { Text(it, fontSize = 12.sp, color = SensiColors.Primary) }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.Bottom) {
                    OutlinedTextField(
                        input, { input = it.take(ChatRepository.MAX_LEN) }, modifier = Modifier.weight(1f), maxLines = 4,
                        placeholder = { Text("Escribe un mensaje…") },
                        supportingText = { Text("${input.length}/${ChatRepository.MAX_LEN}") }
                    )
                    PrimaryButton(if (sending) "…" else "ENVIAR", Modifier.width(96.dp).padding(bottom = 22.dp).alpha(if (canSend) 1f else .5f), enabled = canSend) { doSend() }
                }
            }
        }
        Spacer(Modifier.navigationBarsPadding())
    }
}

@Composable
private fun Bubble(m: ChatMsg, mine: Boolean) {
    val shape = RoundedCornerShape(14.dp)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
        Column(
            Modifier.widthIn(max = 290.dp).clip(shape)
                .background(if (mine) SensiColors.Primary.copy(alpha = .22f) else MaterialTheme.colorScheme.surface)
                .border(BorderStroke(1.dp, if (mine) SensiColors.Primary.copy(alpha = .6f) else SensiColors.GlassBorder), shape)
                .padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            val who = if (mine) "Tú" else "Usuario " + m.uid.takeLast(4).uppercase()
            Text("$who · ${timeLabel(m.createdAt)}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .6f))
            Text(m.text, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
        }
    }
}

private fun timeLabel(iso: String): String = try {
    Instant.parse(iso).atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("HH:mm"))
} catch (e: Exception) { "" }
