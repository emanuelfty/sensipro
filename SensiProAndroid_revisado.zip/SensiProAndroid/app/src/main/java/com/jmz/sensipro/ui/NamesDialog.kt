package com.jmz.sensipro.ui

import android.graphics.Paint
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jmz.sensipro.data.NameStyler
import kotlin.random.Random

/** Pregunta al sistema de fuentes de ESTE teléfono si puede dibujar un carácter (con caché). */
@Composable
private fun rememberGlyphCheck(): (Int) -> Boolean = remember {
    val paint = Paint()
    val cache = HashMap<Int, Boolean>()
    val f: (Int) -> Boolean = { code ->
        cache.getOrPut(code) { paint.hasGlyph(String(Character.toChars(code))) }
    }
    f
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ColumnScope.NamesContent() {
    val ctx = LocalContext.current
    val has = rememberGlyphCheck()
    var base by remember { mutableStateOf("") }
    var fontSel by remember { mutableStateOf<String?>(null) }
    var decoSel by remember { mutableStateOf(NameStyler.DECO_RANDOM) }
    var seed by remember { mutableStateOf(1) }

    val decos = remember { NameStyler.availableDecos(has) }
    val fonts = remember(base) { NameStyler.availableFonts(base.trim().ifEmpty { "Abc" }, has) }
    val results = remember(base, fontSel, decoSel, seed) {
        NameStyler.build(base, fontSel, decoSel, decos, Random(seed), has)
    }

    Text(xt("nmH"), fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
    OutlinedTextField(
        base, { base = it }, singleLine = true, modifier = Modifier.fillMaxWidth(),
        placeholder = { Text(xt("nmIn")) }
    )

    SectionHeader(xt("nmF"))
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Chip(xt("nmAll"), fontSel == null) { fontSel = null }
        fonts.forEach { f -> Chip(f.label, fontSel == f.label) { fontSel = f.label } }
    }

    SectionHeader(xt("nmS"))
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Chip("🎲 " + xt("nmRnd"), decoSel == NameStyler.DECO_RANDOM) { decoSel = NameStyler.DECO_RANDOM }
        Chip(xt("nmNone"), decoSel == NameStyler.DECO_NONE) { decoSel = NameStyler.DECO_NONE }
        decos.forEachIndexed { i, d -> Chip(d.pre + "…" + d.post, decoSel == i) { decoSel = i } }
    }

    if (base.isNotBlank()) {
        PrimaryButton(xt("nmRoll")) { seed++ }
        results.forEach { r ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SheetButton(r.text, Modifier.weight(1f)) { copyName(ctx, r.text) }
                SheetButton(xt("nmCopy"), Modifier.width(96.dp)) { copyName(ctx, r.text) }
            }
        }
    }
}

private fun copyName(ctx: android.content.Context, text: String) {
    copyText(ctx, text)
    toast(ctx, xt("nmCopied"))
}
