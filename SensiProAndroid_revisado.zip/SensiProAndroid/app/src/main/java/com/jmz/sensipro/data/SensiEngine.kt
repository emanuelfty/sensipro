package com.jmz.sensipro.data

import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.min

/** Port 1:1 de la lógica de index-mejorado-1.html (generateHash / getVal / statsFor / dpiFor / buildConfig). */
data class Tier(val id: String, val label: String, val min: Int, val max: Int, val dpiBase: Int)

data class ModelFlags(val highEnd: Boolean, val xiaomi: Boolean)

data class Stats(val g: Int, val r: Int, val m2: Int, val m4: Int, val awm: Int, val lib: Int) {
    fun asPairs(): List<Pair<String, Int>> = listOf(
        "General" to g, "Punto Rojo" to r, "Mira 2x" to m2,
        "Mira 4x" to m4, "AWM" to awm, "Mira Libre" to lib
    )
}

object SensiEngine {
    val TIERS = listOf(
        Tier("alta", "🔴 ALTA", 100, 200, 600),
        Tier("media", "🟡 MEDIA", 80, 180, 500),
        Tier("baja", "🔵 BAJA", 0, 120, 400)
    )

    private val highEndRx = Regex("pro|ultra|iphone|s2[1-9]|fold|flip", RegexOption.IGNORE_CASE)
    private val xiaomiRx = Regex("xiaomi|poco|redmi", RegexOption.IGNORE_CASE)

    fun modelFlags(m: String) = ModelFlags(highEndRx.containsMatchIn(m), xiaomiRx.containsMatchIn(m))

    /**
     * JS: hash = charCodeAt + ((hash << 5) - hash). `<<` aplica ToInt32 y el resultado
     * queda como double sin recortar; se emula con Long.
     */
    fun generateHash(str: String): Long {
        var h = 0L
        for (ch in str) h = ch.code.toLong() + ((h.toInt() shl 5).toLong() - h)
        return abs(h)
    }

    fun seedFor(model: String): Long =
        if (model.isBlank()) 0L else generateHash(model.trim().lowercase())

    private fun getVal(seed: Long, min: Int, max: Int, offset: Int): Int {
        if (seed == 0L) return 0
        val range = max - min
        return (((seed + offset) % range) + min).toInt()
    }

    private fun cap(v: Int) = min(200, v)

    fun statsFor(seed: Long, t: Tier, dpi: Boolean, f: ModelFlags): Stats {
        val off = if (dpi) 15 else 0
        return Stats(
            g = cap(getVal(seed, t.min, t.max, 1) + off + if (f.xiaomi) 5 else 0),
            r = cap(getVal(seed, t.min, t.max, 2) + if (dpi) 8 else 0),
            m2 = cap(getVal(seed, t.min, t.max, 3) + if (f.highEnd) 10 else 0),
            m4 = cap(getVal(seed, t.min, t.max, 4) + off),
            awm = floor(getVal(seed, 20, 90, 5) * (if (dpi) 0.8 else 1.0)).toInt(),
            lib = getVal(seed, t.min, t.max, 6)
        )
    }

    fun dpiFor(seed: Long, t: Tier, f: ModelFlags): Int =
        (t.dpiBase + (seed % 200) + if (f.highEnd) 100 else 0).toInt()

    /** Equivalente a buildConfig() del original (texto para copiar). */
    fun buildConfigText(model: String): String? {
        val m = model.trim()
        if (m.isEmpty()) return null
        val seed = generateHash(m.lowercase()); val f = modelFlags(m)
        val (alta, media, baja) = TIERS
        fun block(s: Stats) = s.asPairs().joinToString("\n") { "${it.first}: ${it.second}" }
        return buildString {
            append("📱 ${m.uppercase()}\n\n")
            append("SIN DPI\n${block(statsFor(seed, media, false, f))}\n\n")
            append("CON DPI\nDPI: ${dpiFor(seed, alta, f)}\n${block(statsFor(seed, alta, true, f))}\n\n")
            append("ALTA\n${block(statsFor(seed, alta, false, f))}\n\n")
            append("MEDIA\n${block(statsFor(seed, media, false, f))}\n\n")
            append("BAJA\n${block(statsFor(seed, baja, false, f))}")
        }
    }
}
