package com.jmz.sensipro

import com.jmz.sensipro.data.SensiEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SensiEngineTest {
    @Test fun emptyModelGivesZeroSeed() = assertEquals(0L, SensiEngine.seedFor(""))

    @Test fun statsNeverExceed200() {
        val seed = SensiEngine.seedFor("xiaomi 14 pro ultra")
        val f = SensiEngine.modelFlags("xiaomi 14 pro ultra")
        SensiEngine.TIERS.forEach { t ->
            SensiEngine.statsFor(seed, t, true, f).asPairs().forEach { assertTrue(it.second <= 200) }
        }
    }
}
