package com.jmz.sensipro

import com.jmz.sensipro.data.NameStyler
import kotlin.random.Random
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class NameStylerTest {
    private val all: (Int) -> Boolean = { true }
    private fun font(label: String) = NameStyler.FONTS.first { it.label == label }

    @Test fun boldMapsLettersAndDigits() = assertEquals("𝐀𝐛𝟏", font("Negrita").apply("Ab1"))

    @Test fun scriptUsesReservedCodePointExceptions() = assertEquals("ℬℯ", font("Script").apply("Be"))

    @Test fun accentsAreStripped() = assertEquals(font("Negrita").apply("Nino"), font("Negrita").apply("Niño"))

    @Test fun unsupportedFontsAreHidden() {
        val noMath: (Int) -> Boolean = { it < 0x1D400 || it > 0x1D7FF }
        val labels = NameStyler.availableFonts("Abc", noMath).map { it.label }
        assertFalse(labels.contains("Negrita"))
        assertTrue(labels.contains("Versalita"))
    }

    @Test fun buildGivesOneResultPerFontAndHonoursSelection() {
        val decos = NameStyler.availableDecos(all)
        assertEquals(NameStyler.FONTS.size, NameStyler.build("Lobo", null, NameStyler.DECO_NONE, decos, Random(1), all).size)
        val one = NameStyler.build("Lobo", "Negrita", 0, decos, Random(1), all)
        assertEquals(1, one.size)
        assertEquals(decos[0].pre + font("Negrita").apply("Lobo") + decos[0].post, one[0].text)
    }

    @Test fun emptyNameGivesNoResults() =
        assertTrue(NameStyler.build("  ", null, NameStyler.DECO_RANDOM, NameStyler.DECOS, Random(1), all).isEmpty())
}
